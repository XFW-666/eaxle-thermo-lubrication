"""
Baseline vs duty-waveform-augmented surrogates.

For each of the five response quantities, seven surrogate families are trained
twice -- once on the six steady-state design inputs alone, and once with the
nine duty-waveform descriptors added -- and evaluated on the same held-out
split.  The trained models are then applied to the eight certified duty cycles
to test whether the waveform descriptors also improve out-of-domain transfer.

Outputs data/processed/surrogate_wf.json.
"""
from __future__ import annotations

import json
import os
import sys

import numpy as np
from waveform_features import trace_speed_mps
import pandas as pd
from sklearn.ensemble import (GradientBoostingRegressor,
                              HistGradientBoostingRegressor,
                              RandomForestRegressor)
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, ConstantKernel, WhiteKernel
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPRegressor

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
PROC = os.path.join(HERE, "..", "data", "processed")

from train_surrogate import PINN          # noqa: E402

DESIGN = ["v_mean", "i_final", "h_ext", "oil_l", "T_amb", "T_cool"]
WAVE = ["v_rms_mps", "v_max_mps", "pke_mps3", "a_rms_mps2", "a_max_mps2",
        "p_pos_W_per_kg", "stop_fraction", "jerk_rms_mps3"]
TARGETS = ["T_flank_proxy", "T_oil_max", "P_mesh_max", "mesh_energy_kJ",
           "lambda_mean"]
SEED = 7


def families():
    return {
        "PINN (residual)": lambda: PINN(mode="residual", seed=1),
        "MLP": lambda: MLPRegressor((64, 32), max_iter=4000, random_state=1),
        "Gradient boosting": lambda: GradientBoostingRegressor(
            n_estimators=600, learning_rate=0.05, max_depth=3, random_state=2),
        "Hist gradient boosting": lambda: HistGradientBoostingRegressor(
            max_iter=800, learning_rate=0.06, max_depth=6,
            l2_regularization=1.0, random_state=4),
        "Random forest": lambda: RandomForestRegressor(
            n_estimators=800, random_state=3),
        "Gaussian process": lambda: GaussianProcessRegressor(
            kernel=ConstantKernel(1.0) * RBF(length_scale=np.ones(6))
            + WhiteKernel(1.0), n_restarts_optimizer=2, random_state=5),
        "Linear": lambda: LinearRegression(),
    }


def make():
    df = pd.read_csv(os.path.join(PROC, "doe_waveform_features.csv"))
    Xb = df[DESIGN].to_numpy(float)
    Xa = df[DESIGN + WAVE].to_numpy(float)
    y = {t: df[t].to_numpy(float) for t in TARGETS}
    return df, Xb, Xa, y


def main():
    df, Xb, Xa, y = make()
    idx = np.arange(len(df))
    itr, ite = train_test_split(idx, test_size=0.25, random_state=SEED)

    fams = families()
    res = {}
    for tgt in TARGETS:
        res[tgt] = {}
        for set_name, X in (("baseline", Xb), ("waveform", Xa)):
            for name, ctor in fams.items():
                try:
                    model = ctor()
                    # the GP kernel length scale must match the feature count
                    if name == "Gaussian process" and X.shape[1] != 6:
                        model = GaussianProcessRegressor(
                            kernel=ConstantKernel(1.0)
                            * RBF(length_scale=np.ones(X.shape[1]))
                            + WhiteKernel(1.0), n_restarts_optimizer=2,
                            random_state=5)
                    model.fit(X[itr], y[tgt][itr])
                    p = model.predict(X[ite])
                    res[tgt][f"{set_name}|{name}"] = dict(
                        R2=float(r2_score(y[tgt][ite], p)),
                        RMSE=float(np.sqrt(mean_squared_error(y[tgt][ite], p))))
                except Exception as e:
                    res[tgt][f"{set_name}|{name}"] = dict(R2=float("nan"),
                                                          error=str(e)[:120])
        best_b = max((k for k in res[tgt] if k.startswith("baseline|")),
                     key=lambda k: res[tgt][k]["R2"])
        best_w = max((k for k in res[tgt] if k.startswith("waveform|")),
                     key=lambda k: res[tgt][k]["R2"])
        print("%-16s baseline %-28s R2=%.3f | waveform %-24s R2=%.3f"
              % (tgt, best_b.split("|")[1], res[tgt][best_b]["R2"],
                 best_w.split("|")[1], res[tgt][best_w]["R2"]))

    # ---------------- transfer to the certified cycles -----------------
    cycles = ["jpn10", "ece", "sc03", "udds", "ftp", "hwy", "us06", "eudc"]

    def _vmean(k):
        d = np.load(os.path.join(PROC, f"cycle_{k}.npz"))
        return float(np.mean(trace_speed_mps(name, d["v"])))

    wf_c = pd.read_csv(os.path.join(PROC, "cycle_waveform_features.csv"),
                       index_col=0)
    truth_flank, truth_lam = [], []
    for k in cycles:
        d = np.load(os.path.join(PROC, f"cycle_{k}_sim.npz"))
        truth_flank.append(float(np.max(d["T_flank_proxy"])))
        truth_lam.append(float(np.mean(d["lambda"])))

    Xc_b, Xc_a = [], []
    for k in cycles:
        vm = _vmean(k)
        row_wf = wf_c.loc[k]
        Xc_b.append([vm, 9.0, 60.0, 0.42, 25.0, 25.0])
        Xc_a.append([vm, 9.0, 60.0, 0.42, 25.0, 25.0]
                    + [float(row_wf[c]) for c in WAVE])
    Xc_b = np.array(Xc_b, float)
    Xc_a = np.array(Xc_a, float)
    truth_flank = np.array(truth_flank)
    truth_lam = np.array(truth_lam)

    transfer = {}
    for tgt, truth in (("T_flank_proxy", truth_flank),
                       ("lambda_mean", truth_lam)):
        for set_name, X in (("baseline", Xb), ("waveform", Xa)):
            best = max((k for k in res[tgt] if k.startswith(set_name + "|")),
                       key=lambda k: res[tgt][k]["R2"])
            name = best.split("|")[1]
            model = families()[name]()
            if name == "Gaussian process" and X.shape[1] != 6:
                model = GaussianProcessRegressor(
                    kernel=ConstantKernel(1.0)
                    * RBF(length_scale=np.ones(X.shape[1])) + WhiteKernel(1.0),
                    n_restarts_optimizer=2, random_state=5)
            model.fit(X, y[tgt])
            pred = model.predict(Xc_a if set_name == "waveform" else Xc_b)
            transfer[f"{tgt}|{set_name}"] = dict(
                family=name, R2=float(r2_score(truth, pred)),
                predictions=[float(x) for x in pred])
            print("transfer %-16s %-9s (%-24s) R2=%.2f"
                  % (tgt, set_name, name, transfer[f"{tgt}|{set_name}"]["R2"]))

    out = dict(results=res, transfer=transfer,
               truth=dict(T_flank_proxy={k: float(v) for k, v in
                                         zip(cycles, truth_flank)}),
               feature_importance={})
    # permutation-free importance: use the augmented HGB importances once
    from sklearn.inspection import permutation_importance
    m = HistGradientBoostingRegressor(max_iter=800, learning_rate=0.06,
                                      max_depth=6, l2_regularization=1.0,
                                      random_state=4).fit(
        Xa[itr], y["T_flank_proxy"][itr])
    pi = permutation_importance(m, Xa[ite], y["T_flank_proxy"][ite],
                                n_repeats=20, random_state=13, scoring="r2")
    out["feature_importance"]["waveform"] = dict(
        zip(DESIGN + WAVE, [float(x) for x in pi.importances_mean]))
    json.dump(out, open(os.path.join(PROC, "surrogate_wf.json"), "w"), indent=2)
    print("written: surrogate_wf.json")


if __name__ == "__main__":
    main()