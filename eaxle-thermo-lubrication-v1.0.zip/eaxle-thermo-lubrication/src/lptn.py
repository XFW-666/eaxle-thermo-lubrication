"""
Industry-standard lumped-parameter thermal network (LPTN) benchmark.

Purpose
-------
The manuscript's central claim is that a lumped network cannot represent the
tooth-flank state of an e-axle reducer.  This module turns that claim into a
quantitative benchmark: a fair, best-practice 4-node LPTN built from the SAME
geometry, the SAME loss sub-models and the SAME coefficients as the
three-dimensional finite-volume solver, driven over the same eight certified
duty cycles, and compared node-for-node.

Network
-------
    ambient
       |  h_ext x A_ext
    housing -- UA_cooler -- (coolant/ambient)
       |  h_int x A_cavity_inner
    oil bath -- h_wall x A_imm -- gear body -- G_seat -- shaft -- h_shaft x A_shaft
    losses: gear node <- P_slide + P_churn(T_oil)
            shaft node <- P_bear + P_wind + MOTOR_LOSS_TO_GEAR x P_motor

All conductances use the same coefficients as the finite-volume model; the
shaft uses its analytic surface (the best-practice lumped value, which is the
area the sub-grid correction was recovering).  Integration: explicit Euler,
dt capped at 0.05 s.
"""
from __future__ import annotations

import json
import os
import sys
import time

import numpy as np
from waveform_features import trace_speed_mps

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
PROC = os.path.join(HERE, "..", "data", "processed")

from fv_eaxle import (FVEaxleSolver, VehicleSpec, MATERIALS, LUBRICANT,  # noqa: E402
                      GEOMETRY, MOTOR_LOSS_TO_GEAR, R_GEAR, R_SHAFT,
                      R_HOUSING, R_OIL, R_AIR)

OUT_JSON = os.path.join(PROC, "lptn_comparison.json")
OUT_TRAJ = os.path.join(PROC, "lptn_trajectories.npz")

H_GEAR = 900.0        # wall-film coefficient, gear faces (same as FV)
H_SHAFT = 450.0       # shaft surface coefficient (same as FV, pre-correction)
H_INT = 220.0         # housing inner-wall forced convection (same as FV)
UA_COOLER = 120.0     # lumped oil-cooler conductance (same as FV)
A_SEAT = 2 * np.pi * 0.016 * 0.020   # shaft-gear contact seat
L_SEAT = 0.010                       # seat conduction length


def build_lptn(solver):
    """Capacitances and conductances from the solver's own geometry."""
    rho_g = MATERIALS["gear"]["rho"]
    cp_g = MATERIALS["gear"]["cp"]
    rho_s = MATERIALS["shaft"]["rho"]
    cp_s = MATERIALS["shaft"]["cp"]
    rho_h = MATERIALS["housing"]["rho"]
    cp_h = MATERIALS["housing"]["cp"]
    rho_o = LUBRICANT["rho_oil_40"]
    cp_o = LUBRICANT["cp"]

    C_gear = rho_g * cp_g * solver.V_gear
    C_oil = rho_o * cp_o * solver.V_oil
    C_housing = rho_h * cp_h * solver.V_housing
    n_shaft = int((solver.region == R_SHAFT).sum())
    C_shaft = rho_s * cp_s * n_shaft * solver.vol

    # housing inner surface: face area of housing cells adjacent to the cavity
    inner = 0.0
    reg = solver.region
    for ax in range(3):
        import numpy as _np
        nb = solver._shift(reg.astype(np.int8), ax, 1)
        wall = (reg == R_HOUSING) & ((nb == R_OIL) | (nb == R_AIR))
        wall &= solver._not_first(ax)
        d = (solver.dx, solver.dy, solver.dz)[ax]
        inner += float(wall.sum()) * d * d

    A_shaft_true = 2 * np.pi * 0.016 * 0.160
    G_seat = MATERIALS["shaft"]["k"] * A_SEAT / L_SEAT

    G = {
        "gear_oil": H_GEAR * solver.A_imm,
        "shaft_oil": H_SHAFT * A_shaft_true,
        "gear_shaft": G_seat,
        "oil_housing": H_INT * inner + UA_COOLER,
        "housing_amb": solver.h_ext * solver.A_ext,
    }
    C = {"gear": C_gear, "shaft": C_shaft, "oil": C_oil, "housing": C_housing}
    return C, G


def run_lptn(solver, t, v, veh, T_amb):
    """Run the LPTN over one duty; returns trajectories and lambda stats."""
    C, G = build_lptn(solver)
    Tg = Ts = To = Th = T_amb
    n = len(t)
    rec_t, rec_g, rec_o, rec_lam = [], [], [], []
    lam_min = float("inf")
    t0 = time.perf_counter()
    dt_max = 0.05
    for i in range(1, n):
        step = min(t[i] - t[i - 1], 1.0)
        a_w = (v[i] - v[i - 1]) / max(t[i] - t[i - 1], 1e-6)
        om_w = v[i] / veh.r_wheel
        T_road = veh.resistance_N(v[i]) * veh.r_wheel
        T_axle = (veh.J * a_w + T_road) / veh.i_final
        om_pin = om_w * veh.i_final
        T_mot = T_axle * GEOMETRY["u"]
        _, loss_mot = veh.pmsm_map(T_mot, om_pin * GEOMETRY["u"])

        Tf = float(np.mean(solver.T[solver.region == R_GEAR]))  # churn basis
        P_slide, P_churn = solver.gear_mesh_power(Tg, T_axle, max(om_pin, 1.0))
        P_bear = solver._bearing_power(Ts, T_axle, max(om_pin, 1.0))
        P_wind = solver._windage_power(max(om_pin, 1.0))
        P_gear = P_slide + P_churn
        P_shaft = P_bear + P_wind + MOTOR_LOSS_TO_GEAR * loss_mot

        nst = int(np.ceil(step / dt_max))
        dt = step / nst
        for _ in range(nst):
            Q_g = P_gear + G["gear_oil"] * (To - Tg) + G["gear_shaft"] * (Ts - Tg)
            Q_s = P_shaft + G["shaft_oil"] * (To - Ts) + G["gear_shaft"] * (Tg - Ts)
            Q_o = (G["gear_oil"] * (Tg - To) + G["shaft_oil"] * (Ts - To)
                   + G["oil_housing"] * (Th - To))
            Q_h = (G["oil_housing"] * (To - Th)
                   + G["housing_amb"] * (T_amb - Th))
            Tg += Q_g / C["gear"] * dt
            Ts += Q_s / C["shaft"] * dt
            To += Q_o / C["oil"] * dt
            Th += Q_h / C["housing"] * dt
        if i % 5 == 0 or i == n - 1:
            lam, _ = solver.lambda_ratio(Tg, max(om_pin, 1.0), abs(T_axle))
            lam_min = min(lam_min, lam)
            rec_t.append(t[i])
            rec_g.append(Tg)
            rec_o.append(To)
            rec_lam.append(lam)
    runtime = time.perf_counter() - t0
    return dict(t=np.array(rec_t), T_gear=np.array(rec_g), T_oil=np.array(rec_o),
                lam=np.array(rec_lam), lam_min=float(lam_min),
                T_gear_max=max(rec_g), runtime=runtime)


def main():
    solver = FVEaxleSolver(nx=40, ny=28, nz=28)
    veh = VehicleSpec()
    cycles = ["jpn10", "ece", "sc03", "udds", "ftp", "hwy", "us06", "eudc"]
    fv = load_json(os.path.join(PROC, "cycle_sim_summary.json"), {})

    # time one fresh FV run for a fair runtime comparison
    d = np.load(os.path.join(PROC, "cycle_us06.npz"))
    tv = d["t"] - d["t"][0]
    vv = trace_speed_mps("us06", d["v"])
    t0 = time.perf_counter()
    solver.run_cycle(tv, vv, veh, 25.0, 25.0, dt_out=5.0, substeps_per_s=4)
    fv_runtime_us06 = time.perf_counter() - t0

    out, traj = {}, {}
    for k in cycles:
        d = np.load(os.path.join(PROC, f"cycle_{k}.npz"))
        t = d["t"] - d["t"][0]
        v = trace_speed_mps(k, d["v"])
        r = run_lptn(solver, t, v, veh, 25.0)
        f = fv.get(k, {})
        lam3, lamL = f.get("lambda_min"), r["lam_min"]
        reg3 = "full-film" if lam3 >= 1.0 else "mixed"
        regL = "full-film" if lamL >= 1.0 else "mixed"
        out[k] = dict(
            T_gear_mean_3D=f.get("T_flank_max"),
            T_flank_proxy_3D=f.get("T_flank_proxy"),
            T_gear_LPTN_max=r["T_gear_max"],
            gap_mean=(r["T_gear_max"] - f.get("T_flank_max")),
            gap_flank=(f.get("T_flank_proxy") - r["T_gear_max"]),
            lambda_min_3D=lam3, lambda_min_LPTN=lamL,
            lambda_ratio_LPTN_over_3D=(lamL / lam3 if lam3 else None),
            regime_3D=reg3, regime_LPTN=regL,
            misclassified=(reg3 != regL),
            runtime_LPTN_s=r["runtime"],
        )
        traj[f"{k}_t"] = r["t"]
        traj[f"{k}_gear"] = r["T_gear"]
        traj[f"{k}_lam"] = r["lam"]
        print("%-6s LPTN gear_max=%6.1f  3D mean=%6.1f  flank99=%6.1f  "
              "lamL=%.3f lam3=%.3f  misclass=%s  t=%.2fs"
              % (k, r["T_gear_max"], f.get("T_flank_max", 0),
                 f.get("T_flank_proxy", 0), r["lam_min"], lam3,
                 reg3 != regL, r["runtime"]), flush=True)

    out["_meta"] = dict(
        fv_runtime_us06_s=fv_runtime_us06,
        lptn_runtime_us06_s=out["us06"]["runtime_LPTN_s"],
        speedup=fv_runtime_us06 / max(out["us06"]["runtime_LPTN_s"], 1e-9),
        misclassified_total=sum(1 for k in cycles if out[k]["misclassified"]),
        note="LPTN = fair best-practice 4-node network on the same losses; "
             "3D flank proxy is what the lumped model cannot produce.",
    )
    json.dump(out, open(OUT_JSON, "w"), indent=2)
    np.savez(OUT_TRAJ, **traj)
    print("written:", OUT_JSON)


def load_json(p, d=None):
    try:
        return json.load(open(p))
    except Exception:
        return d


if __name__ == "__main__":
    main()