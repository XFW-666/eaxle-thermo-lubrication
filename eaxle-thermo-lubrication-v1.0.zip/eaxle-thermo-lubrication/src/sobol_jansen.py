"""
Variance-based global sensitivity (Jansen estimator) for the trained
surrogates.  A one-at-a-time sensitivity is not a variance decomposition and
cannot separate a dominant monotone factor from its interaction terms; the
pick-freeze estimator below gives a genuine first-order and total-order index.
Applied to the surrogate,

    S_j  = 1/(2N) * sum_i [ f(A_i) - f(C_j,i) ]^2 / V ,
    S_Tj = 1/(2N) * sum_i [ f(A_i) - f(B_i) ]^2 / V ,

with C_j the matrix B whose j-th column is replaced by A's j-th column, and
V the variance of the pooled predictions.  Every factor gets a real first-order
and total-order index, for two response quantities.
"""
from __future__ import annotations

import json
import os
import sys

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingRegressor

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
PROC = os.path.join(HERE, "..", "data", "processed")

DESIGN = ["v_mean", "i_final", "h_ext", "oil_l", "T_amb", "T_cool"]
TARGETS = ["T_flank_proxy", "lambda_mean"]
N_MC = 20000
SEED = 20261019


def main():
    df = pd.read_csv(os.path.join(PROC, "doe_results.csv"))
    X = df[DESIGN].to_numpy(float)
    rng = np.random.default_rng(SEED)
    lo, hi = X.min(axis=0), X.max(axis=0)

    out = {"n_mc": N_MC, "seed": SEED, "estimator": "Jansen", "targets": {}}
    for tgt in TARGETS:
        y = df[tgt].to_numpy(float)
        m = HistGradientBoostingRegressor(max_iter=800, learning_rate=0.06,
                                          max_depth=6, l2_regularization=1.0,
                                          random_state=4).fit(X, y)
        A = rng.uniform(lo, hi, size=(N_MC, X.shape[1]))
        B = rng.uniform(lo, hi, size=(N_MC, X.shape[1]))
        fa = m.predict(A)
        fb = m.predict(B)
        V = float(np.var(np.concatenate([fa, fb])))
        S1, ST = {}, {}
        for j, name in enumerate(DESIGN):
            # Jansen: S_j = 1 - E[(f(A) - f(C_j))^2] / (2V),  C_j = B with col j from A
            C = B.copy()
            C[:, j] = A[:, j]
            fc = m.predict(C)
            S1[name] = float(1.0 - np.mean((fa - fc) ** 2) / (2.0 * V))
            # total order: D_j = A with col j from B
            D = A.copy()
            D[:, j] = B[:, j]
            fd = m.predict(D)
            ST[name] = float(np.mean((fa - fd) ** 2) / (2.0 * V))
        out["targets"][tgt] = dict(first_order=S1, total_order=ST,
                                   variance=V,
                                   range=[float(y.min()), float(y.max())])
        print("\n%s  (response range %.2f - %.2f)" % (tgt, y.min(), y.max()))
        for name in DESIGN:
            print("  %-8s S1 = %.3f   ST = %.3f" % (name, S1[name], ST[name]))

    json.dump(out, open(os.path.join(PROC, "sobol_jansen.json"), "w"), indent=2)
    print("\nwritten: sobol_jansen.json")


if __name__ == "__main__":
    main()
