"""
Duty-waveform features for the surrogate models.

The steady-state design inputs (mean duty speed, ratio, cooling, fill,
ambient, coolant) cannot encode the duty waveform, which is why the baseline
surrogates fail on the two instantaneous targets (peak mesh power, minimum
film ratio).  This module computes eight waveform descriptors from a speed
trace -- the information a duty waveform carries beyond its mean speed:

    duration_s        trace length
    v_rms_mps         root-mean-square speed
    v_max_mps         peak speed
    pke_mps3          positive Kinetic Energy per distance (standard severity)
    a_rms_mps2        root-mean-square acceleration
    a_max_mps2        peak acceleration
    p_pos_W_per_kg    mean positive specific traction power (moving time)
    stop_fraction     time fraction at standstill
    jerk_rms_mps3     root-mean-square jerk

PKE and the specific traction power use the vehicle-equivalent mass
m_eq = J / r_wheel^2 (the effective inertia at the wheel), so the descriptors
are physical and transfer across duties of different duration.
"""
from __future__ import annotations

import json
import os
import sys

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
PROC = os.path.join(HERE, "..", "data", "processed")

from fv_eaxle import VehicleSpec            # noqa: E402
from run_simulation import synth_duty       # noqa: E402

FEATURES = ["duration_s", "v_rms_mps", "v_max_mps", "pke_mps3",
            "a_rms_mps2", "a_max_mps2", "p_pos_W_per_kg", "stop_fraction",
            "jerk_rms_mps3"]


def wave_features(t, v, veh):
    dt = np.diff(t)
    a = np.gradient(v, t)
    jerk = np.gradient(a, t)
    moving = v > 0.10
    m_eq = veh.J / veh.r_wheel ** 2

    dv = np.diff(v)
    pos_ke = 0.5 * m_eq * dv[dv > 0] ** 2
    dist = float(np.trapezoid(v, t))
    pke = float(pos_ke.sum() / dist) if dist > 0 else 0.0

    road = veh.resistance_N(np.clip(v, 0, None))
    p_trac = road * v + m_eq * np.maximum(a, 0.0) * v
    p_pos = float(p_trac[moving].mean()) if moving.any() else 0.0

    return {
        "duration_s": float(t[-1] - t[0]),
        "v_rms_mps": float(np.sqrt((v ** 2).mean())),
        "v_max_mps": float(v.max()),
        "pke_mps3": pke,
        "a_rms_mps2": float(np.sqrt((a ** 2).mean())),
        "a_max_mps2": float(a.max()),
        "p_pos_W_per_kg": p_pos / m_eq,
        "stop_fraction": float(1.0 - moving.mean()),
        "jerk_rms_mps3": float(np.sqrt((jerk ** 2).mean())),
    }


def main():
    veh = VehicleSpec()
    doe = pd.read_csv(os.path.join(PROC, "doe_results.csv"))
    design = pd.read_csv(os.path.join(PROC, "doe_design.csv"))

    rows = []
    for i in range(len(doe)):
        dm = float(design.loc[i, "v_mean"])
        t, v = synth_duty(1800.0, dm, seed=1000 + i)
        rows.append(wave_features(t, v, veh))
    wf = pd.DataFrame(rows)
    doe_aug = pd.concat([doe.reset_index(drop=True), wf], axis=1)
    doe_aug.to_csv(os.path.join(PROC, "doe_waveform_features.csv"), index=False)
    print("DOE duties: %d x %d waveform features" % (len(wf), len(FEATURES)))
    print(wf.describe().loc[["mean", "std", "min", "max"]].round(3).to_string())

    # certified cycles
    rows = []
    meta = []
    for k in ["jpn10", "ece", "sc03", "udds", "ftp", "hwy", "us06", "eudc"]:
        d = np.load(os.path.join(PROC, f"cycle_{k}.npz"))
        t = d["t"] - d["t"][0]
        v = trace_speed_mps(name, d["v"])
        rows.append(wave_features(t, v, veh))
        meta.append(k)
    cyc = pd.DataFrame(rows, index=meta)
    cyc.to_csv(os.path.join(PROC, "cycle_waveform_features.csv"))
    print("\ncertified cycles:")
    print(cyc.round(3).to_string())


if __name__ == "__main__":
    main()


# The UN/ECE and Japanese schedules are tabulated in km/h; the EPA schedules
# are tabulated in mph.  Every loader must go through this function so the two
# conventions never get mixed again.
KPH_TRACES = {"ece", "eudc", "jpn10", "nedc", "wltp"}


def trace_speed_mps(name, v_raw):
    """Convert a stored trace to m/s, honouring the unit of its source file."""
    import numpy as np
    v = np.asarray(v_raw, float)
    if str(name).lower() in KPH_TRACES:
        return v / 3.6
    return v * 0.44704
