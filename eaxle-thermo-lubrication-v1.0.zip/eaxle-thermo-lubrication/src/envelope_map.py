"""
Scuffing-limited operating envelope of the reference e-axle.

For each combination of constant vehicle speed and ambient temperature the
three-dimensional model is driven to quasi-steady state and the minimum film
ratio is recorded.  The lambda_min = 1 contour is the full-film boundary: the
fastest sustainable speed at each ambient temperature before the gear mesh
leaves elastohydrodynamic lubrication.

Output: data/processed/envelope_map.json (grid + boundary) for Figure 14.
"""
from __future__ import annotations

import json
import os
import sys
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
PROC = os.path.join(HERE, "..", "data", "processed")

from fv_eaxle import FVEaxleSolver, VehicleSpec   # noqa: E402

SPEEDS = [8.0, 12.0, 16.0, 20.0, 24.0, 28.0, 32.0, 36.0, 40.0, 44.0]  # m/s
AMBIENTS = [5.0, 15.0, 25.0, 35.0, 45.0]                            # degC
T_END = 600.0
LAMBDA_BOUNDARY = 1.0


def run_point(solver, v, T_amb, veh):
    t = np.arange(0.0, T_END + 1.0, 1.0)
    v_t = np.full_like(t, v)
    r = solver.run_cycle(t, v_t, veh, T_amb, T_amb, dt_out=5.0,
                         substeps_per_s=4)
    # same lambda post-processing as run_simulation.py Part 1
    lam = np.array([solver.lambda_ratio(r["T_flank_proxy"][i],
                                        max(abs(r["omega_wheel"][i]
                                                * veh.i_final), 1.0),
                                        float(abs(r["T_axle"][i])))[0]
                    for i in range(len(r["t"]))])
    lam_min = float(np.min(lam))
    lam_end = float(lam[-1])
    flank = float(r["T_flank_proxy"][-1])
    oil = float(np.nanmax(r["T_oil"]))
    return lam_min, lam_end, flank, oil


def main():
    veh = VehicleSpec()
    lam = np.full((len(AMBIENTS), len(SPEEDS)), np.nan)
    flank = np.full_like(lam, np.nan)
    oil = np.full_like(lam, np.nan)
    solver = FVEaxleSolver(nx=40, ny=28, nz=28)
    t0 = time.perf_counter()
    for ia, Ta in enumerate(AMBIENTS):
        for iv, v in enumerate(SPEEDS):
            lm, le, fl, oi = run_point(solver, v, Ta, veh)
            lam[ia, iv] = min(lm, le)
            flank[ia, iv] = fl
            oil[ia, iv] = oi
            print("T_amb=%4.0f  v=%4.0f m/s (%3.0f km/h): lambda=%.3f  "
                  "flank=%6.1f  oil=%5.1f  [%.0fs]"
                  % (Ta, v, v * 3.6, min(lm, le), fl, oi,
                     time.perf_counter() - t0), flush=True)

    # full-film boundary: fastest speed with lambda >= 1, per ambient
    boundary = {}
    for ia, Ta in enumerate(AMBIENTS):
        v_b = None
        for iv, v in enumerate(SPEEDS):
            if lam[ia, iv] >= LAMBDA_BOUNDARY:
                v_b = v
        boundary[str(Ta)] = v_b
        print("T_amb=%4.0f -> full-film speed limit: %s"
              % (Ta, v_b if v_b is None else "%.0f m/s (%.0f km/h)"
                 % (v_b, v_b * 3.6)))

    json.dump(dict(speeds_mps=SPEEDS, ambients_c=AMBIENTS,
                   lambda_min=lam.tolist(), flank_proxy_c=flank.tolist(),
                   oil_c=oil.tolist(), boundary_speed_mps=boundary,
                   lambda_boundary=LAMBDA_BOUNDARY, t_end_s=T_END),
              open(os.path.join(PROC, "envelope_map.json"), "w"), indent=2)
    print("written: envelope_map.json  (%.0f s total)"
          % (time.perf_counter() - t0))


if __name__ == "__main__":
    main()