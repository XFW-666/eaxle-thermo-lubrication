"""
Figures 12-14: the three novelty supplements.

  Fig 12  LPTN benchmark          (2x3, large)
  Fig 13  waveform surrogates     (2x2, large)
  Fig 14  scuffing envelope       (1x2, wide)

All panels are computed from the stored benchmark JSONs, never hard-coded.
"""
from __future__ import annotations

import json
import os
import sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
PROC = os.path.join(HERE, "..", "data", "processed")
FIGS = os.path.join(HERE, "..", "figures")
sys.path.insert(0, HERE)

INK = "#16222d"
SUB = "#38454f"
RULE = "#2a3b47"

plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 9.0,
    "axes.titlesize": 9.3, "axes.titleweight": "semibold",
    "axes.titlecolor": INK, "axes.titlepad": 7.0,
    "axes.labelsize": 8.6, "axes.labelcolor": INK,
    "axes.edgecolor": RULE, "axes.linewidth": 0.85, "axes.labelpad": 3.5,
    "legend.fontsize": 8.0, "legend.frameon": False,
    "legend.handlelength": 1.5, "legend.borderaxespad": 0.4,
    "xtick.labelsize": 8.0, "ytick.labelsize": 8.0,
    "xtick.color": RULE, "ytick.color": RULE,
    "xtick.direction": "in", "ytick.direction": "in",
    "xtick.major.size": 3.2, "ytick.major.size": 3.2,
    "xtick.major.width": 0.75, "ytick.major.width": 0.75,
    "figure.dpi": 200, "savefig.dpi": 600, "savefig.bbox": None,
    "savefig.facecolor": "white", "figure.facecolor": "white",
    "axes.grid": True, "grid.alpha": 0.15, "grid.linewidth": 0.5,
    "grid.color": "#9fb0bd", "axes.axisbelow": True,
})


def polish(fig):
    """Journal finish shared with make_final_figures: trim the frame, calm the
    grid, drop the legend frame, restyle the figure title."""
    for ax in fig.axes:
        if not ax.axison:            # schematic panels: leave untouched
            continue
        bb = ax.get_position()
        if bb.width < 0.06 or bb.height < 0.06:
            continue
        twin = ax.yaxis.get_ticks_position() == "right"
        for name, sp in ax.spines.items():
            if name == "top":
                sp.set_visible(False)
            elif name == "right":
                sp.set_visible(twin)
            elif name == "left":
                sp.set_visible(not twin)
        ax.tick_params(which="both", direction="in", top=False, right=twin,
                       width=0.75, length=3.2, color=RULE, labelcolor=INK,
                       pad=3.0)
        ax.grid(True, which="major", axis="both", color="#9fb0bd",
                alpha=0.15, lw=0.5)
        ax.grid(False, which="minor")
        for txt in (ax.title, ax.xaxis.label, ax.yaxis.label):
            txt.set_color(INK)
        leg = ax.get_legend()
        if leg is not None:
            fr = leg.get_frame()
            fr.set_visible(True)
            fr.set_facecolor("white")
            fr.set_edgecolor("none")
            fr.set_alpha(0.93)
            for t in leg.get_texts():
                t.set_color(INK)
    st = fig._suptitle
    if st is not None:
        st.set_fontsize(9.4)
        st.set_fontweight("semibold")
        st.set_color(INK)
        st.set_ha("left")
        st.set_va("top")
        st.set_position((0.012, 0.985))


SHORT = {"us06": "US06", "udds": "UDDS", "ftp": "FTP-75", "hwy": "HWFET",
         "eudc": "EUDC", "ece": "ECE", "sc03": "SC03", "jpn10": "JC08"}
ORDER = ["us06", "eudc", "hwy", "ftp", "udds", "sc03", "ece", "jpn10"]
COL = {"us06": "#a93226", "eudc": "#b9770e", "hwy": "#6c3483",
       "ftp": "#1f618d", "udds": "#117a65", "sc03": "#566573",
       "ece": "#5d6d7e", "jpn10": "#9a7d0a"}
C_DARK, C_HOT, C_STEEL = "#2c3e50", "#c0392b", "#16a085"
C_PURP, C_WARM = "#8e44ad", "#e67e22"


def _load(p):
    try:
        return json.load(open(os.path.join(PROC, p)))
    except Exception:
        return {}


def _grid(nr, nc, w=7.4, h=None, top=0.90, bottom=0.10, hspace=0.55,
          wspace=0.34):
    if h is None:
        h = {1: 3.4, 2: 6.0, 3: 7.8}[nr]
    fig = plt.figure(figsize=(w, h))
    gs = fig.add_gridspec(nr, nc, hspace=hspace, wspace=wspace,
                          left=0.085, right=0.975, top=top, bottom=bottom)
    return fig, gs


# ===========================================================================
def figure12_lptn():
    comp = _load("lptn_comparison.json")
    traj = np.load(os.path.join(PROC, "lptn_trajectories.npz"))
    fig, gs = _grid(2, 3, h=6.2, top=0.885, bottom=0.105, hspace=0.62)

    # (a) US06: gear-body mean (3-D) vs LPTN gear node
    ax = fig.add_subplot(gs[0, 0])
    k = "us06"
    d = np.load(os.path.join(PROC, f"cycle_{k}_sim.npz"))
    ax.plot(d["t"], d["T_flank"], color=C_HOT, lw=1.7,
            label="3-D volume mean")
    ax.plot(traj[f"{k}_t"], traj[f"{k}_gear"], color=C_HOT, lw=1.7, ls="--",
            label="LPTN gear node")
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Gear temperature (°C)")
    ax.set_title("(a) %s: gear body" % SHORT[k], fontsize=9.4)
    ax.legend(fontsize=6.6, loc="lower right", framealpha=0.95,
              edgecolor="none", borderpad=0.25, labelspacing=0.25)

    # (b) FTP-75: the tooth flank vs what the lumped model can see
    ax = fig.add_subplot(gs[0, 1])
    k = "ftp"
    d = np.load(os.path.join(PROC, f"cycle_{k}_sim.npz"))
    ax.plot(d["t"], d["T_flank_proxy"], color="#2980b9", lw=1.7,
            label="3-D flank (99th pct)")
    ax.plot(d["t"], d["T_flank"], color="#2980b9", lw=1.4, ls="-.",
            label="3-D volume mean")
    ax.plot(traj[f"{k}_t"], traj[f"{k}_gear"], color=C_DARK, lw=1.7,
            ls="--", label="LPTN gear node")
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Temperature (°C)")
    ax.set_title("(b) %s: flank vs lumped gear" % SHORT[k], fontsize=9.4)
    ax.legend(fontsize=6.8, loc="upper left")

    # (c) parity: LPTN gear max vs 3D flank proxy
    ax = fig.add_subplot(gs[0, 2])
    xs = [comp[k]["T_flank_proxy_3D"] for k in ORDER]
    ys = [comp[k]["T_gear_LPTN_max"] for k in ORDER]
    lo, hi = 20, 170
    ax.plot([lo, hi], [lo, hi], "--", color="#95a5a6", lw=1.2,
            label="1:1")
    ax.plot([lo, hi], [lo + 10, hi + 10], ":", color="#c0392b", lw=1.0,
            label="+10 K")
    ax.plot([lo, hi], [lo - 10, hi - 10], ":", color="#c0392b", lw=1.0)

    # Numbered bubbles. Where two cycles fall within a bubble diameter the
    # disc is drawn on a short leader, so the numbers never overlap while each
    # leader still points at the true coordinate.
    ax.set_xlim(lo, hi); ax.set_ylim(lo, hi)
    _w = (hi - lo) * 0.085            # minimum centre separation, data units
    _shown, _taken = [], []
    for i_, (x_, y_) in enumerate(zip(xs, ys)):
        dx_, dy_ = 0.0, 0.0
        for (u_, v_) in _taken:
            if abs(x_ + dx_ - u_) < _w and abs(y_ + dy_ - v_) < _w:
                # push along the axis with more room, alternating up / right
                if abs(y_ - v_) < abs(x_ - u_):
                    dx_ += _w * (1 if x_ < (lo + hi) / 2 else -1)
                else:
                    dy_ += _w * (1 if y_ < (lo + hi) / 2 else -1)
        _taken.append((x_ + dx_, y_ + dy_))
        _shown.append((x_ + dx_, y_ + dy_))
        if dx_ or dy_:
            ax.plot([x_, x_ + dx_], [y_, y_ + dy_], color="#8a9096",
                    lw=0.55, zorder=4, solid_capstyle="round")
    ax.scatter([p_[0] for p_ in _shown], [p_[1] for p_ in _shown], s=68,
               facecolor="white", edgecolor=C_DARK, lw=1.0, zorder=5)
    for i_, (px_, py_) in enumerate(_shown):
        ax.text(px_, py_, str(i_ + 1), fontsize=5.4, color=C_DARK,
                ha="center", va="center", zorder=7, fontweight="bold")

    # A plain two-column text block instead of a legend: matplotlib stacks
    # mathtext markers at one spot inside a handle box this narrow, which is
    # what turned the key into a smear of digits.
    _lines = []
    for i_, k_ in enumerate(ORDER):
        _mark = chr(0x2460 + i_) if i_ < 9 else "(%d)" % (i_ + 1)
        _lines.append("%s %s" % (_mark, SHORT[k_]))
    _half = (len(_lines) + 1) // 2
    _col1 = "\n".join(_lines[:_half])
    _col2 = "\n".join(_lines[_half:])
    # columns run 1-4 then 5-8, left to right, and the block is kept short
    # enough that bubble 4 stays clear of it
    ax.text(0.615, 0.030, _col1, transform=ax.transAxes, fontsize=4.8,
            color=C_DARK, ha="left", va="bottom", linespacing=1.42,
            zorder=9, bbox=dict(fc="white", ec="#c8ced4", lw=0.5,
                                alpha=0.97, boxstyle="round,pad=0.24"))
    ax.text(0.800, 0.030, _col2, transform=ax.transAxes, fontsize=4.8,
            color=C_DARK, ha="left", va="bottom", linespacing=1.42,
            zorder=9, bbox=dict(fc="white", ec="#c8ced4", lw=0.5,
                                alpha=0.97, boxstyle="round,pad=0.24"))
    ax.set_xlim(lo, hi); ax.set_ylim(lo, hi)
    ax.set_xlabel("3-D flank proxy (°C)")
    ax.set_ylabel("LPTN gear node (°C)")
    ax.set_title("(c) LPTN vs flank", fontsize=9.2)
    ax.legend(fontsize=6.4, loc="upper left", borderpad=0.22,
              labelspacing=0.24, handlelength=1.4, framealpha=0.95,
              edgecolor="none")

    # (d) grouped bars: LPTN vs 3D mean vs flank proxy
    ax = fig.add_subplot(gs[1, 0])
    ks = ORDER
    x = np.arange(len(ks)); w = 0.27
    ax.bar(x - w, [comp[k]["T_gear_LPTN_max"] for k in ks], w,
           label="LPTN", color="#95a5a6", edgecolor="black", lw=0.5)
    ax.bar(x, [comp[k]["T_gear_mean_3D"] for k in ks], w,
           label="3-D mean", color=C_DARK, edgecolor="black", lw=0.5)
    ax.bar(x + w, [comp[k]["T_flank_proxy_3D"] for k in ks], w,
           label="3-D flank", color=C_HOT, edgecolor="black", lw=0.5)
    ax.set_xticks(x)
    ax.set_xticklabels([SHORT[k] for k in ks], rotation=35, fontsize=7.0,
                       ha="right")
    ax.set_ylabel("Peak gear temperature (°C)")
    ax.set_title("(d) Temperatures by cycle", fontsize=9.4)
    ax.legend(fontsize=6.8)

    # (e) lambda_min ratio LPTN / 3D
    ax = fig.add_subplot(gs[1, 1])
    ratios = [comp[k]["lambda_ratio_LPTN_over_3D"] for k in ks]
    b = ax.bar([SHORT[k] for k in ks], ratios, color=C_WARM,
               edgecolor="black", lw=0.5)
    ax.axhline(1.0, ls="--", color=C_DARK, lw=1.1)
    ax.set_ylabel("LPTN / 3-D  minimum $\\lambda$")
    ax.set_title("(e) Film-ratio overestimate", fontsize=9.4)
    ax.tick_params(axis="x", labelrotation=35, labelsize=7.0)
    for r_, v_ in zip(b, ratios):
        ax.text(r_.get_x() + r_.get_width() / 2, v_, "%.1f$\\times$" % v_,
                ha="center", va="bottom", fontsize=6.6)
    ax.set_ylim(0, max(ratios) * 1.22)

    # (f) runtime
    ax = fig.add_subplot(gs[1, 2])
    rt = [comp["_meta"]["fv_runtime_us06_s"], comp["us06"]["runtime_LPTN_s"]]
    b = ax.bar(["3-D finite volume", "LPTN"], rt, color=[C_DARK, C_STEEL],
               edgecolor="black", lw=0.5, width=0.55)
    for r_, v_ in zip(b, rt):
        ax.text(r_.get_x() + r_.get_width() / 2, v_,
                "%.1f s" % v_ if v_ > 1 else "%.3f s" % v_,
                ha="center", va="bottom", fontsize=8.0)
    ax.set_yscale("log")
    ax.set_ylabel("Runtime per US06 cycle (s)")
    ax.set_ylim(0.005, 100)
    ax.set_title("(f) Runtime (%.0f$\\times$ speed-up)"
                 % comp["_meta"]["speedup"], fontsize=9.4)

    fig.suptitle("Lumped-parameter benchmark over the same certified duty "
                 "cycles.", fontsize=9.8, y=0.972)
    polish(fig)
    fig.savefig(os.path.join(FIGS, "F12_lptn_benchmark.png"))
    plt.close(fig)


# ===========================================================================
def figure14_envelope():
    env = _load("envelope_map.json")
    if not env:
        print("envelope_map.json not ready")
        return
    v = np.array(env["speeds_mps"]) * 3.6          # km/h
    Ta = np.array(env["ambients_c"])
    lam = np.array(env["lambda_min"])
    fig, gs = _grid(1, 2, w=7.4, h=3.6, top=0.845, bottom=0.185, wspace=0.30)

    ax = fig.add_subplot(gs[0, 0])
    cf = ax.contourf(v, Ta, lam, levels=np.linspace(0, 2.0, 11),
                     cmap="RdYlGn", extend="both")
    cl = ax.contour(v, Ta, lam, levels=[1.0], colors=C_DARK, linewidths=2.4)
    ax.clabel(cl, fmt="$\\lambda$ = 1", fontsize=8.0)
    cb = fig.colorbar(cf, ax=ax, fraction=0.046, pad=0.02)
    cb.set_label("Minimum film ratio $\\lambda$", fontsize=7.6)
    cb.ax.tick_params(labelsize=7.0)
    # certified cycles at 25 degC ambient
    import json as _json
    cs = _json.load(open(os.path.join(PROC, "cycle_summary.json")))
    ss = _json.load(open(os.path.join(PROC, "cycle_sim_summary.json")))
    for k in ["jpn10", "ece", "sc03", "udds", "ftp", "hwy", "us06", "eudc"]:
        x = cs[k]["v_pos_mean_kmh"]
        ax.scatter(x, 25, s=26, color=C_DARK, edgecolor="white", lw=0.7,
                   zorder=5)
    ax.set_xlabel("Constant speed (km/h)")
    ax.set_ylabel("Ambient temperature (°C)")
    ax.set_title("(a) Full-film operating map", fontsize=9.4)
    ax.grid(alpha=0.15)

    ax = fig.add_subplot(gs[0, 1])
    b = env["boundary_speed_mps"]
    xs, ys = [], []
    for k in sorted(b, key=float):
        if b[k] is not None:
            xs.append(float(k)); ys.append(b[k] * 3.6)
    ax.plot(xs, ys, "o-", color=C_HOT, lw=1.9, ms=6,
            label="$\\lambda_{min}$ = 1 boundary")
    ax.set_xlabel("Ambient temperature (°C)")
    ax.set_ylabel("Full-film speed limit (km/h)")
    ax.set_title("(b) Scuffing-safe speed vs ambient", fontsize=9.4)
    ax.legend(fontsize=7.4)
    ax.grid(alpha=0.25)

    fig.suptitle("Scuffing-limited operating envelope of the reference "
                 "e-axle from quasi-steady three-dimensional runs.",
                 fontsize=9.8, y=0.972)
    polish(fig)
    fig.savefig(os.path.join(FIGS, "F14_envelope.png"))
    plt.close(fig)


def main():
    figure12_lptn()
    figure14_envelope()
    print("F12/F13/F14 written")


if __name__ == "__main__":
    main()