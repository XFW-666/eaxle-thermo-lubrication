"""
Parse official EPA / regulatory driving cycle traces downloaded from epa.gov.
Source: U.S. EPA, "Dynamometer Drive Schedules"
        https://www.epa.gov/vehicle-and-fuel-emissions-testing/dynamometer-drive-schedules
        and 40 CFR Part 86, Appendix I (https://www.ecfr.gov/current/title-40/part-86)
All traces are real, tabulated, second-by-second speed schedules published by EPA.
"""
import glob
import json
import io
import os

import numpy as np

RAW = os.path.join(os.path.dirname(__file__), "..", "data", "raw")
OUT = os.path.join(os.path.dirname(__file__), "..", "data", "processed")
os.makedirs(OUT, exist_ok=True)

# EPA files are tab-delimited "time, speed"; speed unit varies (mph vs km/h)
UNIT_MPH = {"udds", "ftp", "us06", "sc03", "hwy", "la92", "ece", "eudc", "jpn10"}
K = 0.44704  # mph -> m/s


def parse_epa(fn):
    txt = open(fn, "rb").read().decode("latin-1")
    T, V = [], []
    for line in txt.splitlines():
        line = line.strip().replace('"', "")
        if not line:
            continue
        parts = [p.strip() for p in line.split("\t") if p.strip()]
        if len(parts) < 2:
            parts = [p.strip() for p in line.split(",") if p.strip()]
        if len(parts) < 2:
            continue
        try:
            t, v = float(parts[0]), float(parts[1])
        except ValueError:
            continue
        T.append(t)
        V.append(v)
    return np.array(T), np.array(V)


def resample_1hz(t, v):
    """EPA traces are non-uniform in time for some cycles; put on a strict 1 Hz grid."""
    grid = np.arange(np.floor(t[0]), np.ceil(t[-1]) + 1.0, 1.0)
    return grid, np.interp(grid, t, v)


def cycle_stats(t, v, unit_mph=True):
    k = K if unit_mph else 1.0 / 3.6
    vm = v * k                                    # m/s
    a = np.gradient(vm, t)                       # m/s^2
    pos_d = np.trapezoid(np.where(vm >= 0, vm, 0.0), t)   # positive-motion distance
    dist = np.trapezoid(np.abs(vm), t)                   # absolute (incl. any reverse)
    return {
        "duration_s": float(t[-1] - t[0] + 1),
        "distance_km": float(dist / 1000.0),
        "v_max_kmh": float(vm.max() * 3.6),
        "v_mean_kmh": float(np.trapezoid(vm, t) / t[-1] * 3.6),
        "v_pos_mean_kmh": float(pos_d / t[-1] * 3.6),
        "a_max_ms2": float(a.max()),
        "a_min_ms2": float(a.min()),
        "n_stops": int(np.sum((v[:-1] < 0.5) & (v[1:] < 0.5))),
        "rpc": float(pos_d / max(dist, 1e-9)),
        "pke_ms2": float(np.trapezoid(np.abs(a) ** 2 * vm, t) / max(pos_d, 1e-9)),
        "vrms_kmh": float(np.sqrt(np.trapezoid(vm ** 2, t) / t[-1]) * 3.6),
        "abs_accel_rms": float(np.sqrt(np.trapezoid(np.abs(a) ** 2, t) / t[-1])),
    }



KPH_FILES = {"ece", "eudc", "jpn10"}


def speed_unit(fn):
    """Read the column header and return True when the file is in mph."""
    try:
        head = io.open(fn, encoding="latin-1").read(400).lower()
    except OSError:
        return True
    if "kph" in head or "km/h" in head:
        return False
    return True


def main():
    summary = {}
    for fn in sorted(glob.glob(os.path.join(RAW, "epa_*.txt"))):
        key = os.path.basename(fn)[4:-4]
        t, v = parse_epa(fn)
        if len(t) < 50:
            print(f"{key}: too short ({len(t)}) -- skipped")
            continue
        t, v = resample_1hz(t, v)
        # clean: v<0 -> 0 (EPA schedules contain no negative speed, but guard anyway)
        v = np.clip(v, 0, None)
        st = cycle_stats(t, v, unit_mph=speed_unit(fn))
        st["n_points"] = int(len(t))
        st["source_file"] = os.path.basename(fn)
        summary[key] = st
        np.savez(os.path.join(OUT, f"cycle_{key}.npz"), t=t, v=v, **st)
        print(f"{key:8s} n={len(t):5d} T={st['duration_s']:6.0f}s "
              f"d={st['distance_km']:6.2f}km vmax={st['v_max_kmh']:6.1f} "
              f"vavg={st['v_pos_mean_kmh']:5.1f} amax={st['a_max_ms2']:5.2f} "
              f"RPC={st['rpc']:.3f} PKE={st['pke_ms2']:5.2f}")

    with open(os.path.join(OUT, "cycle_summary.json"), "w") as f:
        json.dump(summary, f, indent=2)
    print(f"\n{len(summary)} cycles parsed -> {OUT}")


if __name__ == "__main__":
    main()