"""
Final figure set: ten separate figures, no cobbling, large readable panels.

Layout principle
----------------
Each figure carries ONE argument.  Panels are grouped by topic, never by
whatever happened to fit.  A six-panel figure uses a 2x3 grid on a 7.4 x 5.6 in
canvas, so each panel is roughly 3.4 x 2.3 in and every label is legible at
print size.  Where two original six-panel figures address the same question they
are paired into a single twelve-panel figure on a taller canvas with generous
row spacing; no panel is ever discarded.

  Fig 1   certified driving cycles                        6 panels   2x3
  Fig 2   study framework and provenance                   6 panels   2x3
  Fig 3   model schematic and mesh verification            9 panels   3x3
  Fig 4   3-D temperature fields and cycle response       12 panels   4x3
  Fig 5   lubrication, duty accumulation, scuffing        12 panels   4x3
  Fig 6   electric drive unit power-loss budget            6 panels   2x3
  Fig 7   design of experiments and surrogate models       6 panels   2x3
  Fig 8   surrogate transfer and uncertainty              12 panels   4x3
  Fig 9   concept map of the design question              6 panels   2x3
  Fig 10  thermo-lubrication mechanism                     6 panels   2x3

Every panel of the original ten-figure, sixty-panel set is carried over.
"""
from __future__ import annotations

import json
import os
import sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle

HERE = os.path.dirname(os.path.abspath(__file__))
PROC = os.path.join(HERE, "..", "data", "processed")
FIGS = os.path.join(HERE, "..", "figures")
sys.path.insert(0, HERE)
os.makedirs(FIGS, exist_ok=True)

from fv_eaxle import (FVEaxleSolver, VehicleSpec, GEOMETRY, R_GEAR,   # noqa: E402
                      R_SHAFT, R_OIL, R_AIR, R_HOUSING,
                      viscosity_mm2s, MOTOR_LOSS_TO_GEAR)

# ---------------------------------------------------------------- styling
INK = "#16222d"
SUB = "#38454f"
RULE = "#2a3b47"

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 9.0,
    "axes.titlesize": 9.3,
    "axes.titleweight": "semibold",
    "axes.titlecolor": INK,
    "axes.titlepad": 7.0,
    "axes.labelsize": 8.6,
    "axes.labelcolor": INK,
    "axes.edgecolor": RULE,
    "axes.linewidth": 0.85,
    "axes.labelpad": 3.5,
    "legend.fontsize": 8.0,
    "legend.frameon": False,
    "legend.handlelength": 1.5,
    "legend.borderaxespad": 0.4,
    "xtick.labelsize": 8.0,
    "ytick.labelsize": 8.0,
    "xtick.color": RULE,
    "ytick.color": RULE,
    "xtick.direction": "in",
    "ytick.direction": "in",
    "xtick.major.size": 3.2,
    "ytick.major.size": 3.2,
    "xtick.major.width": 0.75,
    "ytick.major.width": 0.75,
    "xtick.minor.size": 1.8,
    "ytick.minor.size": 1.8,
    "xtick.minor.width": 0.5,
    "ytick.minor.width": 0.5,
    "figure.dpi": 200,
    "savefig.dpi": 600,
    "savefig.bbox": None,
    "savefig.pad_inches": 0.10,
    "savefig.facecolor": "white",
    "figure.facecolor": "white",
    "axes.grid": True,
    "grid.alpha": 0.15,
    "grid.linewidth": 0.5,
    "grid.color": "#9fb0bd",
    "axes.axisbelow": True,
})

SHORT = {"us06": "US06", "udds": "UDDS", "ftp": "FTP-75", "hwy": "HWFET",
         "eudc": "EUDC", "ece": "ECE", "sc03": "SC03", "jpn10": "JC08"}
COL = {"us06": "#a93226", "eudc": "#b9770e", "hwy": "#6c3483",
       "ftp": "#1f618d", "udds": "#117a65", "sc03": "#566573",
       "ece": "#5d6d7e", "jpn10": "#9a7d0a"}
ORDER = ["us06", "eudc", "hwy", "ftp", "udds", "sc03"]

C_DARK, C_STEEL, C_HOT = "#2c3e50", "#117a65", "#a93226"
C_WARM, C_COOL, C_PURP = "#b9770e", "#1f618d", "#6c3483"
C_GREY, C_LIGHT = "#5d6d7e", "#eef2f5"



def polish(fig, title=None):
    """Journal finish: trim the frame, calm the grid, tighten the legend.

    Data panels lose their top and right spines; a twin axis keeps the right
    spine (the reader needs that scale) but loses the left one.  Narrow axes
    (colour bars, inset keys) are left untouched.
    """
    for ax in fig.axes:
        if not ax.axison:            # schematic panels: leave untouched
            continue
        bb = ax.get_position()
        if bb.width < 0.06 or bb.height < 0.06:      # colour bars, inset keys
            continue
        twin = ax.yaxis.get_ticks_position() == "right"
        for name, sp in ax.spines.items():
            if name == "top":
                sp.set_visible(False)
            elif name == "right":
                sp.set_visible(twin)
            elif name == "left":
                sp.set_visible(not twin)
        ax.tick_params(which="both", direction="in", top=False,
                       right=twin, width=0.75, length=3.2, color=RULE,
                       labelcolor=INK, pad=3.0)
        ax.grid(True, which="major", axis="both", color="#9fb0bd",
                alpha=0.15, lw=0.5)
        ax.grid(False, which="minor")
        for txt in (ax.title, ax.xaxis.label, ax.yaxis.label):
            txt.set_color(INK)
        leg = ax.get_legend()
        if leg is not None:
            fr = leg.get_frame()
            fr.set_visible(True)
            fr.set_facecolor("white")
            fr.set_edgecolor("none")
            fr.set_alpha(0.93)
            leg.get_frame().set_edgecolor("none")
            for t in leg.get_texts():
                t.set_color(INK)
    st = fig._suptitle
    if st is not None:
        st.set_fontsize(9.4)
        st.set_fontweight("semibold")
        st.set_color(INK)
        st.set_ha("left")
        st.set_va("top")
        st.set_position((0.012, 0.985))


def load_sims():
    out = {}
    for f in sorted(os.listdir(PROC)):
        if f.startswith("cycle_") and f.endswith("_sim.npz"):
            out[f[len("cycle_"):-len("_sim.npz")]] = np.load(os.path.join(PROC, f))
    return out


def load_json(p, d=None):
    try:
        return json.load(open(p))
    except Exception:
        return d


def grid(nrows, ncols, w=7.4, h=None, top=0.90, bottom=0.10, hspace=0.55,
         wspace=0.34, right=0.975):
    """Figure skeleton sized so panels stay large and legible."""
    if h is None:
        h = {1: 3.2, 2: 5.6, 3: 7.8, 4: 10.0}[nrows]
    fig = plt.figure(figsize=(w, h))
    gs = fig.add_gridspec(nrows, ncols,
                          hspace=hspace, wspace=wspace,
                          left=0.085, right=right, top=top, bottom=bottom)
    return fig, gs


def _box(ax, x, y, w, h, label, fc, tc="white", fs=8.5, r=0.02):
    ax.add_patch(FancyBboxPatch(
        (x, y), w, h, boxstyle=f"round,pad=0,rounding_size={r}",
        facecolor=fc, edgecolor=fc, linewidth=1.0, zorder=3))
    ax.text(x + w / 2, y + h / 2, label, ha="center", va="center",
            fontsize=fs, color=tc, zorder=4, linespacing=1.35)


def _arrow(ax, p0, p1, color=C_GREY, lw=1.4, ms=10):
    from matplotlib.patches import FancyArrowPatch
    ax.add_patch(FancyArrowPatch(p0, p1, arrowstyle="-|>",
                                 mutation_scale=ms, color=color,
                                 linewidth=lw, zorder=2,
                                 shrinkA=1.5, shrinkB=1.5))


# ===========================================================================
# Figure 1 — certified driving cycles (6 panels, 2x3)
# ===========================================================================
def figure1_cycles():
    cyc, cs = {}, load_json(os.path.join(PROC, "cycle_summary.json"), {})
    for f in sorted(os.listdir(PROC)):
        if f.startswith("cycle_") and f.endswith(".npz") and "_sim" not in f:
            cyc[f[len("cycle_"):-len(".npz")]] = np.load(os.path.join(PROC, f))

    names = [("udds", "UDDS"), ("ftp", "FTP-75"), ("us06", "US06"),
             ("hwy", "HWFET"), ("eudc", "EUDC"), ("sc03", "SC03")]
    fig, gs = grid(2, 3, h=5.6, top=0.84, bottom=0.11, hspace=0.48)
    for k, (nm, lab) in enumerate(names):
        ax = fig.add_subplot(gs[k // 3, k % 3])
        d = cyc[nm]
        t = d["t"] - d["t"][0]
        v = d["v"] * 0.44704
        ax.plot(t, v * 3.6, color=COL[nm], lw=0.7)
        ax.set_xlabel("Time (s)")
        ax.set_ylabel("Speed (km/h)")
        ax.set_ylim(0, 140)
        if nm in cs:
            ax.set_title("(%s) %s — %.2f km, %.0f s"
                         % ("abcdef"[k], lab, cs[nm]["distance_km"],
                            cs[nm]["duration_s"]), fontsize=9.4)
        else:
            ax.set_title("(%s) %s" % ("abcdef"[k], lab), fontsize=9.4)
    fig.suptitle("Certified duty cycles from the U.S. EPA archive.", fontsize=9.8, y=0.972)
    polish(fig)
    fig.savefig(os.path.join(FIGS, "F1_cycles.png"))
    plt.close(fig)


# ===========================================================================
# Figure 2 — study framework and provenance (6 panels, 2x3)
# ===========================================================================

def energy_closure_pct():
    """Adiabatic energy-balance closure (%), shared by the framework figure and
    the model figure so the two can never disagree."""
    s3 = FVEaxleSolver(nx=32, ny=22, nz=22)
    s3.h_ext = 0.0
    s3.T[:] = 25.0

    def _nocool(rhs, T, Tin):
        m = s3.n_oil
        Tw = np.zeros_like(T)
        cnt = np.zeros_like(T)
        for axx in range(3):
            nb = s3._shift(s3.region.astype(np.int8), axx, 1)
            w = m & (nb <= 2)
            if not w.any():
                continue
            Tw += s3._shift(T, axx, 1) * w
            cnt += w.astype(float)
        Tb = float(np.mean(T[m]))
        wm = np.divide(Tw, np.maximum(cnt, 1.0))
        rate = np.where(cnt > 0, 900.0, 120.0)
        tgt = np.where(cnt > 0, wm, Tb)
        rhs[m] += rate[m] * (tgt[m] - T[m]) * (3.0 / (s3.vol ** (1 / 3))) / \
            s3.heat_capacity_nz[m]
    s3._oil_coupling = _nocool
    E0 = float(np.sum(s3.heat_capacity * s3.T)) * s3.vol
    Qin, nst = 1200.0, 1500
    for _ in range(nst):
        s3.step(0.01, Qin, 0.0, 25.0, q_oil_frac=0.0)
    Einj = Qin * 0.01 * nst
    Est = float(np.sum(s3.heat_capacity * s3.T)) * s3.vol - E0
    return 100.0 * (Est / Einj - 1.0)


# ===========================================================================
# Figure 2 - study framework (4 panels)
# ===========================================================================
def figure2_framework():
    INK = "#1a2733"
    SUB = "#3d4a56"
    fig = plt.figure(figsize=(7.4, 5.0))
    gs = fig.add_gridspec(2, 3, hspace=0.34, wspace=0.30,
                          left=0.02, right=0.98, top=0.885, bottom=0.055)

    # ---------------- (a) computational chain (compact top row) -----------
    ax = fig.add_subplot(gs[0, :])
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    ax.text(0.0, 1.045, "(a) Computational chain and the verification applied "
            "at each stage", fontsize=9.4, color=INK)
    stages = [("I. Certified\nduty input", "#1f6feb"),
              ("II. 3-D finite-volume\nsolver", "#2c3e50"),
              ("III. Design of\nexperiments", "#117a65"),
              ("IV. Physics-constrained\nsurrogate", "#6c3483")]
    _clos = energy_closure_pct()
    _v1 = "distance vs published:" + chr(10) + "1.4 " + chr(37)
    _v2 = "energy closure " + ("%+.2f" % _clos) + " " + chr(37) + ":" + chr(10) \
        + "grid 0.2 K"
    _v3 = "Latin hypercube," + chr(10) + "rate-limited duty"
    _v4 = "held-out 25 " + chr(37) + "," + chr(10) + "5-fold CV + Sobol"
    ver = [_v1, _v2, _v3, _v4]
    w = 0.205
    for i, ((lab, col), v) in enumerate(zip(stages, ver)):
        x0 = 0.01 + i * 0.245
        _box(ax, x0, 0.44, w, 0.34, lab, col, fs=8.0)
        if i < 3:
            _arrow(ax, (x0 + w + 0.004, 0.61), (x0 + 0.240, 0.61), lw=1.5)
        _box(ax, x0 + w / 2 - 0.088, 0.075, 0.176, 0.225, v, "white",
             fs=6.8)
        ax.add_patch(Rectangle((x0 + w / 2 - 0.088, 0.075), 0.176, 0.225,
                               fill=False, edgecolor="#b9c2c9", lw=0.9,
                               zorder=3))
        ax.text(x0 + w / 2, 0.187, v, ha="center", va="center", fontsize=6.8,
                color=INK, zorder=4, linespacing=1.30)
        _arrow(ax, (x0 + w / 2, 0.425), (x0 + w / 2, 0.312), lw=1.0, ms=7)

    # ---------------- (b) provenance ---------------------------------------
    ax = fig.add_subplot(gs[1, 0])
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    ax.set_title("(b) Data provenance", fontsize=9.4, color=INK, pad=6)
    srcs = [("U.S. EPA schedules", "40 CFR Pt.86 App. I", "#1f6feb", "EPA"),
            ("SAE J306_202502, ISO 6336", "ASTM D3418, ISO 3448", "#117a65",
             "STD"),
            ("ASM Handbook Vol. 1", "AlSi10Mg, 20MnCr5", "#2c3e50", "MAT"),
            ("VED, 383 in-use vehicles", "Apache-2.0", "#b9770e", "VED"),
            ("56 refs + 8 standards", "DOIs via Crossref", "#6c3483", "REF"),
            ("Generated, not measured", "gear geometry from spec.", "#5b6b7a",
             "GEN")]
    def _ink(hexcol):
        """Dark ink on a light chip, white on a dark one."""
        h = hexcol.lstrip("#")
        r, g, b = (int(h[i:i + 2], 16) / 255.0 for i in (0, 2, 4))
        lum = 0.2126 * r + 0.7152 * g + 0.0722 * b
        return "white" if lum < 0.55 else "#16222d"

    y = 0.90
    for name, detail, col, gl in srcs:
        ax.add_patch(FancyBboxPatch((0.0, y - 0.050), 0.105, 0.135,
                                    boxstyle="round,pad=0,rounding_size=0.012",
                                    facecolor=col, edgecolor="none"))
        ax.text(0.0525, y + 0.014, gl, fontsize=5.6, color=_ink(col),
                ha="center", va="center", fontweight="bold")
        ax.text(0.125, y + 0.026, name, fontsize=6.9, color=INK, va="center")
        ax.text(0.125, y - 0.030, detail, fontsize=6.2, color=SUB, va="center")
        y -= 0.150

    # ---------------- (c) cross-section + physics callouts -----------------
    ax = fig.add_subplot(gs[1, 1])
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    ax.set_title("(c) Physical content per stage", fontsize=9.4, color=INK,
                 pad=6)
    import matplotlib.patheffects as pe
    from matplotlib.patches import (Circle as _Cc, FancyBboxPatch as _Fb,
                                    Polygon as _Pg)
    ax.add_patch(_Fb((0.02, 0.06), 0.42, 0.84,
                     boxstyle="round,pad=0,rounding_size=0.035",
                     fc="#8a9299", ec="#39424a", lw=1.5, zorder=1))
    ax.add_patch(Rectangle((0.055, 0.115), 0.35, 0.73, fc="#f4f8fb",
                           ec="#39424a", lw=0.9, zorder=2))
    ax.add_patch(Rectangle((0.055, 0.115), 0.35, 0.215, fc="#e08e3c",
                           ec="none", zorder=3))
    ax.plot([0.055, 0.405], [0.330, 0.330], color="#a9691f", lw=1.0,
            ls="--", zorder=4)
    th = np.linspace(0, 2 * np.pi, 20, endpoint=False)
    ring = np.concatenate([
        np.column_stack([0.180 + 0.108 + 0.014 * np.cos(th),
                         0.600 + 0.014 * np.sin(th)]),
        np.column_stack([0.180 + 0.086 * np.cos(th),
                         0.600 + 0.086 * np.sin(th)])])
    ax.add_patch(_Pg(ring, closed=True, fc="#b03a2e", ec="#7b241c", lw=1.0,
                     zorder=5))
    ax.add_patch(_Cc((0.180, 0.600), 0.028, fc="#7b241c", ec="none",
                     zorder=6))
    ax.add_patch(_Cc((0.330, 0.295), 0.062, fc="#b03a2e", ec="#7b241c",
                     lw=1.0, zorder=5))
    ax.add_patch(_Cc((0.330, 0.295), 0.019, fc="#7b241c", ec="none",
                     zorder=6))
    ax.add_patch(Rectangle((0.148, 0.585), 0.064, 0.032, fc="#117a65",
                           ec="#0b4c3f", lw=0.9, zorder=7))
    ax.text(0.230, 0.800, "cavity air", fontsize=5.8, color="#39424a",
            ha="center", zorder=8)
    ax.text(0.230, 0.215, "oil bath", fontsize=5.8, color="white", ha="center",
            fontweight="bold", zorder=8)
    ax.text(0.180, 0.600, "gear", fontsize=5.8, color="white", ha="center",
            va="center", fontweight="bold", zorder=8)
    ax.text(0.330, 0.295, "pinion", fontsize=5.2, color="white", ha="center",
            va="center", zorder=8)
    # halo width below glyph stroke width
    ax.text(0.052, 0.470, "housing", fontsize=5.4, color="#14202b",
            ha="center", fontweight="bold", zorder=8, rotation=90,
            path_effects=[pe.withStroke(linewidth=0.8, foreground="white")])
    calls = [("4 loss mechanisms", "mesh, churn, bearing, windage", "#b9770e"),
             ("ASTM D3418", "ν(T), two-point fit", "#117a65"),
             ("Hamrock-Dowson", "λ = H / σ", "#117a65"),
             ("ISO 6336", "μ(λ), EHL to boundary", "#b03a2e")]
    y = 0.86
    for name, detail, col in calls:
        ax.add_patch(FancyBboxPatch((0.500, y - 0.048), 0.024, 0.098,
                                    boxstyle="round,pad=0,rounding_size=0.008",
                                    facecolor=col, edgecolor="none"))
        ax.text(0.540, y + 0.030, name, fontsize=6.0, color=INK, va="center",
                fontweight="bold")
        ax.text(0.540, y - 0.028, detail, fontsize=5.3, color=SUB,
                va="center", linespacing=1.45)
        y -= 0.215

    # ---------------- (d) governing question (plain academic layout) -------
    ax = fig.add_subplot(gs[1, 2])
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    ax.set_title("(d) The governing question", fontsize=9.4, color=INK, pad=6)

    # question
    ax.add_patch(_Fb((0.0, 0.660), 1.00, 0.280,
                     boxstyle="round,pad=0,rounding_size=0.02",
                     fc=INK, ec="none"))
    ax.text(0.50, 0.868, "Which duty and geometry keep", fontsize=6.4,
            color="white", ha="center", va="center")
    ax.text(0.50, 0.792, "the reduction gear out of", fontsize=6.4,
            color="white", ha="center", va="center")
    ax.text(0.50, 0.716, "boundary lubrication?", fontsize=6.4, color="white",
            ha="center", va="center")

    # the two lever groups, as a labelled pair of bracketed sets
    ax.add_patch(Rectangle((0.0, 0.330), 0.478, 0.215, fc="#e8f3ee",
                           ec="#117a65", lw=1.0))
    ax.text(0.239, 0.500, "Designer owns", fontsize=6.6, color="#0b4c3f",
            ha="center", va="center", fontweight="bold")
    ax.text(0.239, 0.408, "cooling, oil fill," + chr(10)
            + "geometry, ratio", fontsize=6.0, color=INK,
            ha="center", va="center", linespacing=1.4)
    ax.add_patch(Rectangle((0.522, 0.330), 0.478, 0.215, fc="#fdf1e0",
                           ec="#b9770e", lw=1.0))
    ax.text(0.761, 0.500, "Duty cycle fixes", fontsize=6.6, color="#7d4a00",
            ha="center", va="center", fontweight="bold")
    ax.text(0.761, 0.408, "mean speed, peaks," + chr(10)
            + "soak, ambient", fontsize=5.8, color=INK,
            ha="center", va="center", linespacing=1.4)

    # arrows into the answer
    ax.annotate("", xy=(0.40, 0.258), xytext=(0.28, 0.322),
                arrowprops=dict(arrowstyle="-|>", color="#5b6b7a", lw=1.1))
    ax.annotate("", xy=(0.60, 0.258), xytext=(0.72, 0.322),
                arrowprops=dict(arrowstyle="-|>", color="#5b6b7a", lw=1.1))

    # answer
    ax.add_patch(_Fb((0.0, 0.020), 1.00, 0.200,
                     boxstyle="round,pad=0,rounding_size=0.02",
                     fc="#fdf1ee", ec="#a93226", lw=1.3))
    ax.text(0.50, 0.150, "Answer: " + chr(955) + ", not temperature,",
            fontsize=6.5, color="#a93226", ha="center", va="center",
            fontweight="bold")
    ax.text(0.50, 0.078, "is the state variable", fontsize=6.5,
            color="#a93226", ha="center", va="center", fontweight="bold")

    fig.suptitle("Study framework and data provenance.", fontsize=9.8,
                 y=0.975, color=INK)
    polish(fig)
    fig.savefig(os.path.join(FIGS, "F2_framework.png"))
    plt.close(fig)

# Figure 3 — model schematic and mesh verification (9 panels, 3x3)
# ===========================================================================

def _gear_slice_index(reg, axis):
    """Index along `axis` of the slice that contains the most gear cells.

    The gear teeth are periodic along the axis, so the geometric mid-plane can
    fall in a tooth gap and miss the gear entirely; the slice through the tooth
    centre is the informative one.
    """
    other = tuple(i for i in range(3) if i != axis)
    cnt = (reg == R_GEAR).sum(axis=other)
    return int(np.argmax(cnt))


def figure3_model(solver):
    reg = solver.region
    fig = plt.figure(figsize=(7.4, 12.0))
    gs = fig.add_gridspec(4, 3, height_ratios=[1.45, 0.92, 0.92, 0.92],
                          hspace=0.52, wspace=0.34,
                          left=0.075, right=0.975, top=0.945, bottom=0.040)

    # (a) cutaway, spanning the top row - drawn to scale from the region field
    ax = fig.add_subplot(gs[0, :])
    ax.axis("off")
    from matplotlib.patches import (FancyBboxPatch as _FB, Polygon as _PG,
                                    Rectangle as _RC)
    k = _gear_slice_index(reg, 1)      # slice through a gear tooth
    sl = reg[:, k, :]                       # (nx, nz) section
    xe = np.concatenate([solver.x - solver.dx / 2,
                         [solver.x[-1] + solver.dx / 2]])
    ze = np.concatenate([solver.z - solver.dz / 2,
                         [solver.z[-1] + solver.dz / 2]])

    def _bx(rid):
        m = sl == rid
        ix = np.where(m.any(axis=1))[0]
        iz = np.where(m.any(axis=0))[0]
        if len(ix) == 0:
            return None
        return (xe[ix.min()], xe[ix.max() + 1],
                ze[iz.min()], ze[iz.max() + 1])

    bxH = _bx(R_HOUSING)
    # The naive `!= housing` bbox is inflated to the whole computational domain
    # by the ambient-air cells outside the shell, which painted the oil bath
    # across the domain and buried the housing wall.  The cavity is therefore
    # taken as the connected non-housing component that contains the gear.
    from scipy.ndimage import label as _ndlabel
    _lab, _n = _ndlabel(sl != R_HOUSING)
    mG0 = sl == R_GEAR
    _ix, _iz = np.where(mG0)
    mCav = _lab == _lab[_ix[0], _iz[0]]
    ixC = np.where(mCav.any(axis=1))[0]
    izC = np.where(mCav.any(axis=0))[0]
    Cx0, Cx1 = xe[ixC.min()], xe[ixC.max() + 1]
    Cz0, Cz1 = ze[izC.min()], ze[izC.max() + 1]
    bxO = _bx(R_OIL)
    bxG = _bx(R_GEAR)
    bxS = _bx(R_SHAFT)
    OTop = bxO[3]
    gx0, gx1, gz0, gz1 = bxG

    # housing shell: dark outer body, light cavity cut away
    ax.add_patch(_FB((bxH[0], bxH[2]), bxH[1] - bxH[0], bxH[3] - bxH[2],
                     boxstyle="round,pad=0,rounding_size=0.012",
                     fc="#b7bfc6", ec="#39424a", lw=2.2, hatch="////",
                     zorder=1))
    ax.add_patch(_FB((Cx0, Cz0), Cx1 - Cx0, Cz1 - Cz0,
                     boxstyle="round,pad=0,rounding_size=0.010",
                     fc="#eef5fb", ec="#39424a", lw=1.6, zorder=2))
    # computational-domain boundary (ambient air fills the rest of the grid)
    ax.add_patch(_RC((xe[0], ze[0]), xe[-1] - xe[0], ze[-1] - ze[0],
                     fill=False, ec="#b0b6bc", lw=1.0, ls=":", zorder=1))
    # oil bath with its free surface
    ax.add_patch(_RC((Cx0, Cz0), Cx1 - Cx0, OTop - Cz0,
                     fc="#e67e22", ec="none", alpha=0.95, zorder=3))
    ax.plot([Cx0, Cx1], [OTop, OTop], color="#b9770e", lw=1.3, ls="--",
            zorder=4)
    # gear drawn as a to-scale disc with radial teeth (the region bbox gives
    # the pitch extents; the disc uses the smaller of the two half-extents so
    # the outline stays circular instead of filling the whole cavity)
    gcx, gcz = 0.5 * (gx0 + gx1), 0.5 * (gz0 + gz1)
    # equal-area equivalent radius: the slice of a gear is a rectangle, so its
    # bbox overestimates the disc; the area-preserving radius keeps the
    # drawing proportional to the resolved region
    _area = float(np.sum(sl == R_GEAR)) * solver.dx * solver.dz
    r_out = float(np.sqrt(max(_area, 1e-12) / np.pi))
    r_out = min(r_out, 0.42 * min(Cx1 - Cx0, Cz1 - Cz0))
    r_in = 0.86 * r_out
    nteeth = 22
    _th = np.linspace(0, 2 * np.pi, 4 * nteeth, endpoint=False)
    _rr = np.where((np.arange(4 * nteeth) % 4) < 2, r_out, r_in)
    teeth_xy = list(zip(gcx + _rr * np.cos(_th), gcz + _rr * np.sin(_th)))
    ax.add_patch(_PG(teeth_xy, closed=True, fc="#b03a2e", ec="#7b241c",
                     lw=1.3, zorder=5))
    ax.add_patch(_RC((gcx - r_in * 0.55, gcz - r_in * 0.55),
                     r_in * 1.10, r_in * 1.10, fc="#e6b0aa", ec="#7b241c",
                     lw=0.9, zorder=6))
    # keyway / hub
    ax.add_patch(_RC((gcx - r_in * 0.20, gcz - r_in * 0.20),
                     r_in * 0.40, r_in * 0.40, fc="#7b241c", ec="none",
                     zorder=7))
    # shaft: a slim bar through the hub, not a full-height block
    ax.add_patch(plt.Circle((gcx, gcz), 0.30 * r_in, fc="#117a65",
                            ec="#0b4c3f", lw=1.0, zorder=8))
    # heat paths
    _arrow(ax, (gcx + r_out + 0.052, gcz + 0.040),
           (gcx + r_out * 0.92, gcz + 0.012), color=C_HOT, lw=2.2, ms=13)
    ax.text(gcx + r_out + 0.048, gcz + 0.058, "mesh loss in", fontsize=7.6,
            color=C_HOT, ha="right")
    _sx = gcx - r_out * 0.55
    _arrow(ax, (_sx, gcz - r_out * 0.92), (_sx, OTop + 0.004), color=C_WARM,
           lw=1.9, ms=11)
    ax.text(_sx + 0.008, 0.5 * (gcz - r_out + OTop), "splash 25 %",
            fontsize=7.4, color=C_WARM, ha="left", va="center")
    xcH = 0.5 * (bxH[0] + bxH[1])
    _arrow(ax, (xcH, bxH[2]), (xcH, bxH[2] - 0.026), color=C_COOL,
           lw=1.9, ms=11)
    ax.text(xcH, bxH[2] - 0.032, "h_ext", fontsize=7.8, color=C_COOL,
            ha="center", va="top")
    # labels with leader lines, placed to avoid overlap
    ax.text(0.5 * (bxH[0] + bxH[1]), bxH[3] + 0.008, "housing  ADC12",
            fontsize=7.0, color="#16222d", ha="center", va="bottom",
            fontweight="semibold")
    # the gear reaches the cavity top, so the only free air is the narrow
    # strip left of the gear: label it vertically inside that strip
    ax.text(0.5 * (Cx0 + gx0), 0.30 * (Cz0 + Cz1), "cavity air",
            fontsize=6.8, color="#16222d", ha="center", va="center",
            rotation=90, fontweight="semibold")
    ax.annotate("shaft  42CrMo4",
                xy=(gcx - r_out - 0.008, gcz),
                xytext=(xe[0] + 0.010, gcz + 0.115),
                fontsize=7.4, color="#0b4c3f", ha="left",
                fontweight="semibold",
                arrowprops=dict(arrowstyle="-", color="#5d6d7e", lw=0.9))
    import matplotlib.patheffects as _pe
    ax.text(gcx, gcz + r_in * 0.62, "gear", fontsize=7.2,
            color="#3d0f10", ha="center", va="center", fontweight="bold",
            zorder=9, path_effects=[_pe.withStroke(linewidth=1.8,
                                                   foreground="white")])
    ax.text(gcx, gcz + r_in * 0.40, "20MnCr5", fontsize=6.2,
            color="#3d0f10", ha="center", va="center", zorder=9,
            path_effects=[_pe.withStroke(linewidth=1.8,
                                         foreground="white")])
    ax.text(0.5 * (Cx0 + Cx1), 0.5 * (Cz0 + OTop), "oil bath\nPAO VG 220",
            fontsize=7.8, color="white", ha="center", va="center",
            fontweight="bold", linespacing=1.3, zorder=6)
    ax.set_xlim(xe[0] - 0.014, xe[-1] + 0.014)
    ax.set_ylim(ze[0] - 0.052, ze[-1] + 0.068)
    ax.text(xe[0] - 0.012, ze[-1] + 0.060,
            "(a) Model cutaway at the mid-plane: five resolved regions and "
            "the three dominant heat paths", fontsize=9.4, fontweight="medium",
            color=C_DARK, ha="left", va="bottom")
    ax.text(0.5 * (xe[0] + xe[-1]), ze[0] - 0.042,
            "drawn to scale from the computed region field - the lubricant "
            "sees the tooth surface, not the gear-body mean",
            ha="center", va="top", fontsize=7.2, color="#7b241c",
            style="italic")
    ax.text(xe[-1] - 0.008, ze[0] + 0.010,
            "computational domain\n(ambient at h_ext)", fontsize=7.0,
            color="#16222d", ha="right", va="bottom", fontweight="semibold",
            linespacing=1.35,
            bbox=dict(fc="white", ec="#9fb0bd", lw=0.6, alpha=0.95,
                      boxstyle="round,pad=0.20"))

    # (b) region volumes
    ax = fig.add_subplot(gs[1, 0])
    names = ["Housing", "Gear", "Shaft", "Oil", "Air"]
    vols = [solver.V_housing * 1e3, solver.V_gear * 1e3,
            float((reg == R_SHAFT).sum()) * solver.vol * 1e3,
            solver.V_oil * 1e3,
            float((reg == R_AIR).sum()) * solver.vol * 1e3]
    cols = ["#7f8c8d", "#2c3e50", "#16a085", "#e67e22", "#ecf0f1"]
    b = ax.barh(names[::-1], vols[::-1], color=cols[::-1],
                edgecolor=C_DARK, lw=0.7)
    for r, v in zip(b, vols[::-1]):
        ax.text(v * 1.18, r.get_y() + r.get_height() / 2, f"{v:.2f} L",
                va="center", fontsize=7.4)
    ax.set_xlabel("Volume (L)")
    ax.set_xlim(0, max(vols) * 1.55)
    ax.set_title("(b) Region volumes", fontsize=9.4)
    ax.tick_params(labelsize=7.6)
    ax.grid(axis="y", alpha=0.15)

    # (c) voxelised bodies
    ax = fig.add_subplot(gs[1, 1], projection="3d")
    sel = (reg == R_HOUSING) | (reg == R_GEAR) | (reg == R_SHAFT)
    ii, jj, kk = np.where(sel)
    sub = np.random.default_rng(0).choice(len(ii), size=min(11000, len(ii)),
                                          replace=False)
    rr = reg[ii[sub], jj[sub], kk[sub]]
    ccols = np.where(rr == R_GEAR, "#c0392b",
                     np.where(rr == R_SHAFT, "#16a085", "#7f8c8d"))
    ax.scatter(solver.x[ii[sub]] * 1e3, solver.y[jj[sub]] * 1e3,
               solver.z[kk[sub]] * 1e3, c=ccols, s=2.8, alpha=0.55, lw=0,
               depthshade=True)
    ax.set_xlabel("x (mm)", fontsize=7.2, labelpad=-3)
    ax.set_ylabel("y (mm)", fontsize=7.2, labelpad=-3)
    ax.set_zlabel("z (mm)", fontsize=7.2, labelpad=-3)
    ax.tick_params(labelsize=6.4, pad=-2)
    ax.set_title("(c) Voxelised housing, gear, shaft", fontsize=9.0, pad=-2)
    ax.view_init(elev=20, azim=-60)

    # (d) gear specification - ruled table plus a to-scale meshing sketch
    ax = fig.add_subplot(gs[1, 2])
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    g = GEOMETRY
    ax.set_title("(d) Gear-pair specification", fontsize=9.0,
                 color="#16222d", pad=6)
    rows = [("teeth  z1 / z2", "%d / %d" % (g["z1"], g["z2"])),
            ("ratio  u", "%.2f : 1" % g["u"]),
            ("module  m_n", "%.1f mm" % (g["m_n"] * 1e3)),
            ("pressure angle", "%.0f$^\\circ$" % g["alpha_n"]),
            ("helix angle", "%.0f$^\\circ$" % g["beta"]),
            ("face width  b", "%.0f mm" % (g["b"] * 1e3)),
            ("pitch  d1 / d2", "%.0f / %.0f mm" % (g["d1"] * 1e3,
                                                  g["d2"] * 1e3)),
            ("bearing  d / D", "40 / 80 mm")]
    ax.text(0.02, 0.965, "parameter", fontsize=6.4, color="#38454f",
            va="center", fontweight="semibold")
    ax.text(0.98, 0.965, "value", fontsize=6.4, color="#38454f",
            va="center", ha="right", fontweight="semibold")
    ax.plot([0.0, 1.0], [0.935, 0.935], color="#16222d", lw=1.0)
    y = 0.890
    for i, (k_, v_) in enumerate(rows):
        if i % 2 == 0:
            ax.add_patch(Rectangle((0.0, y - 0.042), 1.0, 0.084,
                                   fc="#f2f5f7", ec="none", zorder=0))
        ax.text(0.02, y, k_, fontsize=7.0, color="#38454f", va="center",
                zorder=2)
        ax.text(0.98, y, v_, fontsize=7.0, color="#16222d", ha="right",
                va="center", fontweight="semibold", zorder=2)
        y -= 0.072
    ax.plot([0.0, 1.0], [y + 0.041, y + 0.041], color="#9fb0bd", lw=0.7)
    # (d) meshing diagram: upper halves of the addendum circles, drawn to scale
    z1_, z2_ = int(g["z1"]), int(g["z2"])
    m_n = g["m_n"]
    rp1 = 0.5 * m_n * z1_ / np.cos(np.radians(g["beta"]))
    rp2 = 0.5 * m_n * z2_ / np.cos(np.radians(g["beta"]))
    ha_, hf_ = 1.0 * m_n, 1.25 * m_n
    # the wheel is three times the pinion, so a to-scale pair is tall; size it
    # from the height budget between the table and the panel floor
    h_budget = 0.22
    sc = h_budget / (rp2 + ha_)
    cy = 0.118
    c1x = 0.50 - (rp1 + ha_) * sc * 0.95
    c2x = c1x + (rp1 + rp2) * sc

    def _half(cx, r_add, r_root, fc, ec, teeth, lw=1.1):
        th_ = np.linspace(0, np.pi, 90)
        ax.fill(np.concatenate([cx + r_add * sc * np.cos(th_),
                                cx + r_add * sc * np.cos(th_[::-1])]),
                np.concatenate([cy + r_add * sc * np.sin(th_),
                                np.full_like(th_, cy)]),
                fc=fc, ec=ec, lw=lw, zorder=2)
        ax.plot(np.concatenate([cx + r_root * sc * np.cos(th_),
                                cx - r_root * sc * np.concatenate([[0], [0]])]),
                np.concatenate([cy + r_root * sc * np.sin(th_),
                                np.array([cy, cy])]),
                color=ec, lw=0.8, ls=(0, (3, 2)), zorder=3)
        for k_ in range(teeth):
            t_ = np.pi * (k_ + 0.5) / teeth
            ax.plot([cx + r_add * sc * np.cos(t_),
                     cx + (r_add + 1.0 * m_n) * sc * np.cos(t_)],
                    [cy + r_add * sc * np.sin(t_),
                     cy + (r_add + 1.0 * m_n) * sc * np.sin(t_)],
                    color=ec, lw=0.7, zorder=4)

    _half(c1x, rp1 + ha_, rp1 - hf_, "#f2d7d5", "#a93226", max(z1_ // 3, 6))
    _half(c2x, rp2 + ha_, rp2 - hf_, "#d6e6f2", "#1f618d", max(z2_ // 3, 9))
    # centre line and pitch point
    ax.plot([0.02, 0.98], [cy, cy], color="#16222d", lw=0.7,
            ls=(0, (4, 3)), zorder=1)
    # the tooth counts sit under each wheel, as before
    ax.text(c1x, cy - 0.020, "z1 = %d" % z1_, fontsize=6.0, color="#7b241c",
            ha="center", va="top", fontweight="semibold")
    ax.text(c2x, cy - 0.020, "z2 = %d" % z2_, fontsize=6.0, color="#1a5276",
            ha="center", va="top", fontweight="semibold")
    ax.text(0.5, 0.008, "u = %.2f, drawn to scale" % (z2_ / z1_),
            fontsize=5.0, color="#38454f", ha="center", va="bottom",
            style="italic")
    ax.plot([c2x], [cy], marker="o", ms=3.0, mfc="white", mec="#16222d",
            mew=0.9, zorder=6)
    # labels below the centre line, clear of the outlines

    # (e) structured grid, full view with a magnified cell block
    ax = fig.add_subplot(gs[2, 0])
    kz = reg.shape[0] // 2
    sl = reg[kz]                            # (ny, nz)
    ye = np.concatenate([solver.y - solver.dy / 2,
                         [solver.y[-1] + solver.dy / 2]]) * 1e3
    ze = np.concatenate([solver.z - solver.dz / 2,
                         [solver.z[-1] + solver.dz / 2]]) * 1e3
    from matplotlib.colors import ListedColormap, BoundaryNorm
    region_cols = ["#e8edf1", "#b03a2e", "#117a65", "#c9881f", "#2c3e50"]
    light = ListedColormap(region_cols)
    lnorm = BoundaryNorm([-0.5, 0.5, 1.5, 2.5, 3.5, 4.5], light.N)
    ax.pcolormesh(ye, ze, sl.T, cmap=light, norm=lnorm, shading="flat",
                  rasterized=False)
    for yy in ye:
        ax.axvline(yy, color="#5d6d7e", lw=0.28, alpha=0.55)
    for zz in ze:
        ax.axhline(zz, color="#5d6d7e", lw=0.28, alpha=0.55)
    Xg, Yg = np.meshgrid(solver.y * 1e3, solver.z * 1e3)
    ax.contour(Xg, Yg, (sl == R_HOUSING).T, levels=[0.5], colors="#16222d",
               linewidths=1.4)
    ax.set_xlabel("y (mm)")
    ax.set_ylabel("z (mm)")
    ax.set_title("(e) Structured grid and cell regions", fontsize=9.2,
                 color="#16222d", pad=6)
    ax.tick_params(labelsize=7.2)
    ax.set_aspect("equal")
    ax.grid(False)
    # region key inside the empty corner of the section
    import matplotlib.patheffects as _pe2
    for _rid, _lab in [(R_GEAR, "gear"), (R_SHAFT, "shaft"),
                       (R_OIL, "oil"), (R_HOUSING, "housing"),
                       (R_AIR, "air")]:
        _m = sl == _rid
        if not _m.any():
            continue
        _iy, _iz = np.where(_m)
        if _rid == R_HOUSING:
            _score = (ye[_iy] / 60.0) + (ze[_iz] / 90.0)   # lower-right corner
            _j = int(np.argmax(_score))
        else:
            _j = int(len(_iy) // 2)
        ax.text(ye[_iy[_j]], ze[_iz[_j]], _lab, fontsize=5.6,
                color="#16222d", ha="center", va="center", zorder=7,
                fontweight="semibold",
                path_effects=[_pe2.withStroke(linewidth=1.6,
                                              foreground="white")])
    # (f) thermal-resistance network with conductance values
    ax = fig.add_subplot(gs[2, 1])
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    ax.set_title("(f) Resolved thermal network", fontsize=9.2,
                 color="#16222d", pad=6)
    from matplotlib.patches import FancyBboxPatch as _Fbt

    def node(x, y, w, h, title, sub, col):
        ax.add_patch(_Fbt((x, y), w, h,
                          boxstyle="round,pad=0,rounding_size=0.018",
                          fc="white", ec=col, lw=1.2, zorder=3))
        _fs = 5.4 if w < 0.20 else 6.4
        ax.text(x + w / 2, y + h * 0.64, title, fontsize=_fs, color=col,
                ha="center", va="center", fontweight="bold", zorder=5,
                clip_on=False)
        ax.text(x + w / 2, y + h * 0.26, sub, fontsize=_fs - 0.6,
                color="#38454f", ha="center", va="center", zorder=5)

    node(0.305, 0.760, 0.39, 0.140, "gear body", "heat source", "#a93226")
    node(0.305, 0.480, 0.39, 0.140, "oil bath", "churn + film", "#b9770e")
    node(0.305, 0.200, 0.39, 0.140, "housing", "external film", "#16222d")
    node(0.005, 0.480, 0.185, 0.140, "cooler", "120 W/K", "#117a65")
    node(0.810, 0.480, 0.185, 0.140, "ambient", "25 degC", "#5d6d7e")

    def arrow(x0, y0, x1, y1, lw, col, label=None, lx=0.0, ly=0.0, fs=5.6):
        _arrow(ax, (x0, y0), (x1, y1), lw=lw, ms=9, color=col)
        if label:
            ax.text(lx, ly, label, fontsize=fs, color=col, ha="left",
                    va="center", fontweight="semibold")

    arrow(0.500, 0.760, 0.500, 0.620, 3.2, "#a93226")
    arrow(0.500, 0.480, 0.500, 0.340, 2.4, "#b9770e")
    arrow(0.305, 0.550, 0.175, 0.550, 1.5, "#117a65")
    arrow(0.695, 0.550, 0.825, 0.550, 1.5, "#5d6d7e")
    ax.text(0.50, 0.072, "cooler 120 W/K, ambient 25 degC",
            fontsize=4.6, color="#38454f", ha="center", va="center")
    ax.text(0.50, 0.030, "25 % splash, 75 % wall film",
            fontsize=4.6, color="#38454f", ha="center", va="center")

    # (g) grid convergence
    ax = fig.add_subplot(gs[2, 2])
    grids = [(28, 20, 20), (36, 25, 25), (44, 30, 30), (52, 36, 36)]
    Tv, Tf = [], []
    for (a_, b_, c_) in grids:
        s2 = FVEaxleSolver(nx=a_, ny=b_, nz=c_)
        s2.T[:] = 25.0
        for _ in range(3000):
            s2.step(0.01, 900.0, 400.0, 25.0, q_oil_frac=0.25)
        Tg = s2.T[s2.region == R_GEAR]
        Tv.append(float(np.mean(Tg)))
        Tf.append(float(np.percentile(Tg, 90)))
        del s2
    cells = [a_ * b_ * c_ for a_, b_, c_ in grids]
    ax.plot(cells, np.asarray(Tv), "s--", color=C_DARK, lw=1.2, ms=5,
            label="volume mean")
    ax.plot(cells, np.asarray(Tf), "o-", color=C_HOT, lw=1.5, ms=6,
            label="90th-pct flank")
    ax.set_xscale("log")
    ax.set_xticks(cells)
    ax.set_xticklabels(["%.1fk" % (c / 1e3) for c in cells], fontsize=7.6)
    ax.minorticks_off()
    ax.set_xlabel("Number of cells")
    ax.set_ylabel("Gear temperature (°C)")
    ax.set_title("(g) Grid convergence", fontsize=9.2)
    ax.legend(fontsize=5.6, loc="upper right", borderpad=0.28,
              labelspacing=0.30, handlelength=1.3)

    # (h) adiabatic energy-balance closure (shared helper)
    ax = fig.add_subplot(gs[3, 0])
    _clos3 = energy_closure_pct()
    Einj = 1200.0 * 0.01 * 1500
    Est = Einj * (1.0 + _clos3 / 100.0)
    b = ax.bar(["Injected", "Stored"], [Einj / 1e3, Est / 1e3],
               color=[C_DARK, C_STEEL], edgecolor="black", lw=0.5, width=0.55)
    for r_, v_ in zip(b, [Einj, Est]):
        ax.text(r_.get_x() + r_.get_width() / 2, v_ / 1e3,
                f"{v_ / 1e3:.2f} kJ", ha="center", va="bottom", fontsize=7.2)
    ax.set_ylabel("Energy (kJ)")
    ax.set_ylim(0, max(Einj, Est) / 1e3 * 1.30)
    ax.set_title("(h) Adiabatic energy closure %+.2f%%" % _clos3, fontsize=9.4)

    # (i)(j) the two numerical treatments, verified by ablation
    import fv_eaxle as _fx
    dc = np.load(os.path.join(PROC, "cycle_us06.npz"))
    tc = dc["t"] - dc["t"][0]
    vc = dc["v"] * 0.44704
    ends = [60, 120, 180, 240, 300, 360]
    cases = [("both treatments applied", None, None, C_STEEL, "-", "o"),
             ("no sub-grid correction", 1.0, None, C_HOT, "--", "s"),
             ("no motor-loss routing", None, 1.0, C_PURP, "-.", "^")]
    res = {}
    for name, co, rt, col, ls, mk in cases:
        sh, fl = [], []
        for end in ends:
            i_w = int(np.searchsorted(tc, end))
            s2 = FVEaxleSolver(nx=40, ny=28, nz=28)
            if co is not None:
                s2._subgrid_correction[R_SHAFT] = co
            old_rt = _fx.MOTOR_LOSS_TO_GEAR
            if rt is not None:
                _fx.MOTOR_LOSS_TO_GEAR = rt
            try:
                s2.run_cycle(tc[:i_w], vc[:i_w], VehicleSpec(), 25.0, 25.0,
                             dt_out=1e9, substeps_per_s=4)
            finally:
                _fx.MOTOR_LOSS_TO_GEAR = old_rt
            sh.append(float(s2.T[s2.region == R_SHAFT].max()))
            fl.append(float(np.percentile(s2.T[s2.region == R_GEAR], 99)))
            del s2
        res[name] = (np.array(ends), np.array(sh), np.array(fl), col, ls, mk)

    ax = fig.add_subplot(gs[3, 1])
    for name, (tt_, sh_, fl_, col, ls, mk) in res.items():
        ax.semilogy(tt_, sh_, ls, color=col, lw=1.7, marker=mk, ms=5,
                    label=name)
    ax.set_xlabel("Time into the US06 duty (s)")
    ax.set_ylabel("Peak shaft temperature (°C)")
    ax.set_yscale("log")
    ax.set_title("(i) Shaft temperature: divergence\nwithout the treatments",
                 fontsize=9.4)
    ax.legend(fontsize=5.3, loc="lower right", borderpad=0.25,
              labelspacing=0.26, handlelength=1.2)
    ax.grid(True, which="both", alpha=0.30)

    ax = fig.add_subplot(gs[3, 2])
    for name, (tt_, sh_, fl_, col, ls, mk) in res.items():
        ax.plot(tt_, fl_, ls, color=col, lw=1.7, marker=mk, ms=5, label=name)
    fmax = max(v[2].max() for v in res.values())
    ax.set_xlabel("Time into the US06 duty (s)")
    ax.set_ylabel("99th-pct flank temperature (°C)")
    ax.set_ylim(20, fmax * 1.18)
    ax.set_title("(j) Gear side unchanged", fontsize=9.0)
    ax.legend(fontsize=5.3, loc="lower right", borderpad=0.25,
              labelspacing=0.26, handlelength=1.2)

    fig.suptitle("Three-dimensional finite-volume model and its verification.", fontsize=9.8, y=0.972)
    polish(fig)
    fig.savefig(os.path.join(FIGS, "F3_model.png"))
    plt.close(fig)


# ===========================================================================
# Figure 5 - 3-D temperature fields and cycle response (12 panels, 4x3)
# ===========================================================================

def _us06_snapshot(solver, t_target=450.0):
    cyc = np.load(os.path.join(PROC, "cycle_us06.npz"))
    v = cyc["v"] * 0.44704
    t = cyc["t"] - cyc["t"][0]
    s = FVEaxleSolver(nx=solver.region.shape[0], ny=solver.region.shape[1],
                      nz=solver.region.shape[2])
    i_want = len(t) - 1
    for i in range(1, len(t)):
        if t[i] >= t_target:
            i_want = i
            break
    s.run_cycle(t[:i_want + 1], v[:i_want + 1], VehicleSpec(), 25.0, 25.0,
                dt_out=1e9, substeps_per_s=4)
    return s, t[i_want]


def figure5_fields_cycle(solver, sims, ss):
    fig, gs = grid(4, 3, h=10.4, top=0.920, bottom=0.055,
                   hspace=0.42, wspace=0.34, right=0.965)
    s, tt = _us06_snapshot(solver)
    rise = np.maximum(s.T - 25.0, 0.0)
    vmax = float(rise.max())

    # (a-c) the three orthogonal sections on a shared nonlinear scale
    from matplotlib.colors import PowerNorm
    import matplotlib.patheffects as pe
    vmax = float(rise.max())
    pnorm = PowerNorm(gamma=0.42, vmin=0.0, vmax=vmax)
    # axis convention: region axes are (0=x, 1=y, 2=z); a section removes one
    # axis, and the remaining two become (columns, rows) after transpose
    secs = [(1, "x-z section", s.x * 1e3, s.z * 1e3,
             _gear_slice_index(s.region, 1)),
            (0, "y-z axial cut", s.y * 1e3, s.z * 1e3,
             _gear_slice_index(s.region, 0)),
            (2, "x-y horizontal cut", s.x * 1e3, s.y * 1e3,
             _gear_slice_index(s.region, 2))]
    rname = {R_GEAR: "gear", R_SHAFT: "shaft", R_OIL: "oil",
             R_AIR: "air", R_HOUSING: "housing"}
    # per-region label offsets (mm) and the regions small enough to skip
    roff = {R_GEAR: (0, 10), R_OIL: (0, 0), R_AIR: (0, 12),
            R_HOUSING: (0, -12)}
    rskip = {R_SHAFT}
    for k, (axis, name, a1, a2, mid) in enumerate(secs):
        ax = fig.add_subplot(gs[0, k])
        field = np.take(rise, mid, axis=axis).T
        regf = np.take(s.region, mid, axis=axis).T
        h1 = 0.5 * (a1[1] - a1[0])
        h2 = 0.5 * (a2[1] - a2[0])
        e1 = np.concatenate([a1 - h1, [a1[-1] + h1]])
        e2 = np.concatenate([a2 - h2, [a2[-1] + h2]])
        im = ax.imshow(field, origin="lower", cmap="inferno", norm=pnorm,
                       aspect="equal", interpolation="bilinear",
                       extent=[e1[0], e1[-1], e2[0], e2[-1]])
        X, Y = np.meshgrid(e1, e2)
        # crop to the housing: the ambient air outside the shell carries no
        # information and shrinks the structure
        mHs = regf == R_HOUSING
        if mHs.any():
            iyh, ixh = np.where(mHs)
            ax.set_xlim(X[iyh, ixh].min() - 8, X[iyh, ixh].max() + 8)
            ax.set_ylim(Y[iyh, ixh].min() - 8, Y[iyh, ixh].max() + 8)
        for rid in (R_GEAR, R_SHAFT, R_OIL, R_HOUSING):
            try:
                ax.contour(X, Y, (regf == rid).astype(float), levels=[0.5],
                           colors="white", linewidths=0.9)
            except Exception:
                pass
        area = regf.size
        for rid in (R_GEAR, R_OIL, R_HOUSING):
            m = regf == rid
            if m.sum() < 0.04 * area:
                continue
            iy, ix = np.where(m)
            if rid == R_HOUSING:
                # anchor the housing label on the outer wall: the centroid of
                # a thin shell is the section centre, which reads as if the
                # housing were in the middle of the gear
                d2 = (X[iy, ix]) ** 2 + (Y[iy, ix]) ** 2
                j = int(np.argmax(d2))
                lx, ly = X[iy[j], ix[j]], Y[iy[j], ix[j]]
            else:
                dx_, dy_ = roff.get(rid, (0, 0))
                lx, ly = X[iy, ix].mean() + dx_, Y[iy, ix].mean() + dy_
            ax.text(lx, ly, rname[rid], color="#14202b", fontsize=7.0,
                    ha="center", va="center", fontweight="bold",
                    path_effects=[pe.withStroke(linewidth=2.0,
                                                foreground="white")])
        ax.set_title("(%s) %s" % ("abc"[k], name), fontsize=9.4)
        if k == 0:
            ax.text(0.03, 0.97,
                    "US06, t = %.0f s" % tt,
                    transform=ax.transAxes, fontsize=5.6, color="#16222d",
                    va="top", ha="left",
                    bbox=dict(fc="white", ec="#9fb0bd", lw=0.5, alpha=0.95,
                              boxstyle="round,pad=0.22"))
            ax.text(0.03, 0.885, "T_amb = 25 degC, rise shown",
                    transform=ax.transAxes, fontsize=5.2, color="#38454f",
                    va="top", ha="left", style="italic")
        ax.set_xlabel("mm")
        ax.set_ylabel("mm")
        ax.grid(False)
        if k == 2:
            cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.02)
            cb.set_label("T - 25 °C (K)", fontsize=7.4)
            cb.ax.tick_params(labelsize=7.0)

    # (d-f) the three regions traced over the duty
    for k, (key, lab) in enumerate([("T_flank", "gear"), ("T_oil", "oil bath"),
                                    ("T_housing", "housing")]):
        ax = fig.add_subplot(gs[1, k])
        for c_ in ORDER:
            if c_ not in sims:
                continue
            ax.plot(sims[c_]["t"], sims[c_][key], color=COL[c_], lw=1.1,
                    label=SHORT[c_])
            if key == "T_flank" and "T_flank_proxy" in sims[c_]:
                ax.plot(sims[c_]["t"], sims[c_]["T_flank_proxy"], color=COL[c_],
                        lw=1.0, ls="--", alpha=0.85)
        ax.set_xlabel("Time (s)")
        ax.set_ylabel("%s T (°C)" % lab)
        _span = max(float(np.nanmax(sims[c_][key]))
                    for c_ in ORDER if c_ in sims) -                 min(float(np.nanmin(sims[c_][key]))
                    for c_ in ORDER if c_ in sims)
        ax.set_title("(%s) %s, span %.1f K" % ("def"[k], lab, _span),
                     fontsize=9.0, pad=4)
        if _span < 2.0:
            ax.text(0.97, 0.94, "note the %.1f K axis" % _span,
                    transform=ax.transAxes, fontsize=5.8, color="#a93226",
                    va="top", ha="right")
        if k == 0:
            ax.legend(ncol=2, fontsize=5.5, loc="lower right",
                      bbox_to_anchor=(0.995, 0.015), borderpad=0.26,
                      labelspacing=0.28, handlelength=1.2,
                      columnspacing=0.75, handletextpad=0.45)

    # (g-i) the three time histories
    for k, (key, ylab, title, logy) in enumerate([
            ("gap", "Flank minus gear mean (K)", "Flank-to-mean gap", False),
            ("P_mesh", "Mesh power (kW)", "Gear-mesh power", False),
            ("lambda", "Film ratio " + chr(955), "Film-ratio trajectory", True)]):
        ax = fig.add_subplot(gs[2, k])
        for c_ in ORDER:
            if c_ not in sims:
                continue
            if key == "gap":
                if "T_flank_proxy" not in sims[c_]:
                    continue
                y_ = sims[c_]["T_flank_proxy"] - sims[c_]["T_flank"]
            elif key == "P_mesh":
                if key not in sims[c_]:
                    continue
                y_ = sims[c_][key] / 1000.0
            else:
                if key not in sims[c_]:
                    continue
                y_ = sims[c_][key]
            ax.plot(sims[c_]["t"], y_, color=COL[c_], lw=1.1,
                    label=SHORT[c_])
        ax.set_xlabel("Time (s)")
        ax.set_ylabel(ylab)
        ax.set_title("(%s) %s" % ("ghi"[k], title), fontsize=9.2, pad=3)
        if logy:
            ax.set_yscale("log")
            ax.axhline(1.0, ls="--", c=C_DARK, lw=1.1)
            ax.annotate(chr(955) + " = 1", xy=(0.97, 0.06),
                        xycoords="axes fraction", ha="right",
                        va="bottom", fontsize=6.6, color="#16222d",
                        bbox=dict(fc="white", ec="none", alpha=0.9,
                                  boxstyle="round,pad=0.2"))
        if k == 0:
            ax.legend(ncol=2, fontsize=5.5, loc="lower right",
                      bbox_to_anchor=(0.995, 0.015), borderpad=0.26,
                      labelspacing=0.28, handlelength=1.2,
                      columnspacing=0.75, handletextpad=0.45)
    # (j-l) the three summary panels
    ks = [c_ for c_ in ORDER if c_ in ss]
    x = np.arange(len(ks))
    w = 0.38

    ax = fig.add_subplot(gs[3, 0])
    ax.bar(x - w / 2, [ss[c_]["T_flank_proxy"] for c_ in ks], w, label="Flank",
           color="#c0392b", edgecolor="black", lw=0.6)
    ax.bar(x + w / 2, [ss[c_]["T_oil_max"] for c_ in ks], w, label="Oil",
           color="#e67e22", edgecolor="black", lw=0.6)
    ax.set_xticks(x)
    ax.set_xticklabels([SHORT[c_] for c_ in ks], rotation=30, fontsize=7.6)
    ax.set_ylabel("Peak temperature (°C)")
    ax.set_title("(j) Peak temperatures by cycle", fontsize=9.4)
    ax.legend(fontsize=7.2)

    ax = fig.add_subplot(gs[3, 1])
    E = [ss[c_]["mesh_energy_kJ"] for c_ in ks]
    b = ax.bar([SHORT[c_] for c_ in ks], E, color=C_DARK, edgecolor="black",
               lw=0.6)
    ax.set_ylabel("Mesh energy per cycle (kJ)")
    ax.set_title("(k) Cycle-integrated dissipation", fontsize=9.4)
    ax.tick_params(axis="x", labelrotation=30, labelsize=7.6)
    for r_, v_ in zip(b, E):
        ax.text(r_.get_x() + r_.get_width() / 2, v_ / 2, f"{v_:.0f}",
                ha="center", va="center", fontsize=7.0, rotation=90,
                color="white", fontweight="bold")

    ax = fig.add_subplot(gs[3, 2])
    lam = [ss[c_]["lambda_min"] for c_ in ks]
    ax.bar(x, lam, color="#c0392b", edgecolor="black", lw=0.6)
    ax.axhline(1.0, ls="--", c=C_DARK, lw=1.1)
    ax.set_xticks(x)
    ax.set_xticklabels([SHORT[c_] for c_ in ks], rotation=30, fontsize=7.6)
    ax.set_ylabel("Minimum λ")
    ax.set_title("(l) Minimum film ratio", fontsize=9.0)
    for i, v_ in enumerate(lam):
        ax.text(i, v_ + 0.05, f"{v_:.2f}", ha="center", va="bottom",
                fontsize=6.2, color="#1a2733")

    fig.suptitle("Temperature fields and cycle-resolved response.", fontsize=9.8, y=0.972)
    polish(fig)
    fig.savefig(os.path.join(FIGS, "F5_fields_cycle.png"))
    plt.close(fig)


# ===========================================================================
# Figure 6 — lubrication, duty accumulation, scuffing (12 panels, 4x3)
# ===========================================================================
def figure6_lubrication(solver, sims, ss):
    fig, gs = grid(4, 3, h=9.9, top=0.930, bottom=0.045, hspace=0.50,
                   wspace=0.52, right=0.930)
    Tg = np.linspace(40, 140, 160)

    ax = fig.add_subplot(gs[0, 0])
    ax.semilogy(Tg, viscosity_mm2s(Tg), color="#c0392b", lw=1.8)
    ax.set_xlabel("Temperature (°C)")
    ax.set_ylabel("Kinematic viscosity (mm²/s)")
    ax.set_title("(a) ASTM D3418 viscosity law", fontsize=9.2, pad=3)
    ax.text(0.905, 0.960, "fit  nu40 = 220  |  nu100 = 19 mm2/s",
            transform=ax.transAxes, rotation=90, ha="right", va="top",
            fontsize=5.2, color="#1a2733")
    ax.text(0.968, 0.960, "ISO VG 220", transform=ax.transAxes,
            rotation=90, ha="right", va="top", fontsize=5.2,
            color="#1a2733")

    ax = fig.add_subplot(gs[0, 1])
    for om, c in [(20, "#8e44ad"), (80, "#c0392b"),
                  (200, "#e67e22"), (400, "#2c3e50")]:
        lam, _ = solver.lambda_ratio(Tg, om)
        ax.semilogy(Tg, lam, color=c, lw=1.6, label=f"{om} rad/s")
    ax.axhline(1.0, ls="--", c=C_DARK, lw=1.1)
    ax.set_xlabel("Flank temperature (°C)")
    ax.set_ylabel("Film ratio λ", fontsize=7.6)
    ax.set_title("(b) Film ratio: T and speed", fontsize=9.2)
    ax.legend(fontsize=4.8, loc="upper right",
              bbox_to_anchor=(0.998, 0.998), borderpad=0.20,
              labelspacing=0.20, handlelength=1.0, framealpha=1.0,
              edgecolor="none")

    ax = fig.add_subplot(gs[0, 2])
    ax.plot(Tg, [float(solver._mu_of_T(t, 120.0, 150.0)) for t in Tg],
            color="#c0392b", lw=1.9)
    ax.axhline(0.16, ls="--", c=C_GREY, lw=1.0)
    ax.set_ylim(0.12, 0.18)
    ax.set_xlabel("Flank temperature (°C)")
    ax.set_ylabel("Effective friction μ")
    ax.set_title("(c) Friction vs temperature", fontsize=9.2, pad=3)

    ax = fig.add_subplot(gs[1, 0])
    H, _ = solver.lambda_ratio(Tg, 120.0)
    # H is returned in micrometres: convert to nanometres with 1e3
    ax.plot(Tg, H * 1e3, color="#6c3483", lw=1.8)
    ax.axhline(446, ls="--", c="#5d6d7e", lw=1.1)
    ax.text(0.905, 0.960, "composite RMS", transform=ax.transAxes,
            rotation=90, ha="right", va="top", fontsize=5.2,
            color="#1a2733")
    ax.text(0.968, 0.960, "sigma = 0.446 um", transform=ax.transAxes,
            rotation=90, ha="right", va="top", fontsize=5.2,
            color="#1a2733")
    ax.set_xlabel("Flank temperature (°C)")
    ax.set_ylabel("EHL film H_min (nm)")
    ax.set_title("(d) Film vs roughness", fontsize=9.2, pad=3)

    ks = [c_ for c_ in ORDER if c_ in ss]
    x = np.arange(len(ks))

    ax = fig.add_subplot(gs[1, 1])
    lam = [ss[c_]["lambda_min"] for c_ in ks]
    ax.bar(x, lam, color="#c0392b", edgecolor="black", lw=0.6)
    ax.axhline(1.0, ls="--", c=C_DARK, lw=1.1)
    ax.set_xticks(x)
    ax.set_xticklabels([SHORT[c_] for c_ in ks], rotation=30, fontsize=7.6)
    ax.set_ylabel("Minimum λ")
    ax.set_title("(e) Minimum film ratio by cycle", fontsize=9.4)
    for i, v_ in enumerate(lam):
        ax.text(i, v_ + 0.045, f"{v_:.2f}", ha="center", va="bottom",
                fontsize=6.2, color="#1a2733")
    ax.set_ylim(0, 1.24)

    ax = fig.add_subplot(gs[1, 2])
    cyc_acc = np.array([1, 5, 10, 25, 50, 100, 200, 300], dtype=float)
    mu_a = float(solver._mu_of_T(95.0, 120.0, 150.0))
    F_t = 2 * 150.0 / GEOMETRY["d1"]
    v_sl = 0.5 * (120.0 * GEOMETRY["d1"] / 2 * np.sin(np.radians(20))
                  + 120.0 * GEOMETRY["d1"] / 2 * np.sin(np.radians(14)))
    ax.loglog(cyc_acc, mu_a * F_t * v_sl * 1800.0 * cyc_acc / 1e3, "o-",
              color="#c0392b", lw=1.6, ms=5)
    ax.set_xlabel("Cumulative driving cycles")
    ax.set_ylabel("Cumulative friction power (MJ)")
    ax.set_title("(f) Duty-accumulated load", fontsize=9.2, pad=3)

    Ea, Rg = 90000.0, 8.314
    cycles = np.logspace(0, 3.3, 60)
    # peak flank temperature and the duty weight of each cycle, both taken from
    # the simulated cycle summaries rather than typed in by hand
    fig_ax = {}
    for k in ("us06", "udds", "ftp", "hwy", "sc03"):
        v = ss.get(k, {})
        Tpk = float(v.get("T_flank_proxy", np.nan))
        fig_ax[k] = (Tpk, 1.0)      # one cycle of each duty, no weighting

    ax = fig.add_subplot(gs[2, 0])
    for k, (Tpk, w_) in fig_ax.items():
        rate = np.exp(-Ea / (Rg * (Tpk + 273.15)))
        ax.loglog(cycles, w_ * cycles * 1800.0 * rate, lw=1.7, label=SHORT[k],
                  color=COL[k])
    ax.set_xlabel("Cumulative driving cycles")
    ax.set_ylabel("Cumulative scuffing exposure")
    ax.set_title("(g) Arrhenius thermal exposure", fontsize=9.4)
    ax.legend(fontsize=4.8, loc="lower right",
              bbox_to_anchor=(0.998, 0.012), framealpha=0.95,
              edgecolor="none", borderpad=0.20, labelspacing=0.22,
              handlelength=1.0)

    ax = fig.add_subplot(gs[2, 1])
    # exposure consumed per 1000 cycles, from the simulated flank temperature
    Ea2, Rg2 = 90000.0, 8.314
    order = ["sc03", "udds", "ftp", "us06", "hwy"]
    names = [SHORT[k] for k in order]
    per_k = []
    for k in order:
        if k not in ss:
            per_k.append(np.nan)
            continue
        Tp = ss[k]["T_flank_proxy"]
        per_k.append(1000.0 * 1800.0 * np.exp(-Ea2 / (Rg2 * (Tp + 273.15))))
    ypos = np.arange(len(order))
    ax.barh(ypos, per_k, height=0.58,
            color=[COL[k] for k in order], edgecolor="#1a2733", lw=0.5,
            zorder=3)
    for yv, vv in zip(ypos, per_k):
        ax.annotate("%.1e" % vv, xy=(vv, yv), xytext=(3, 0),
                    textcoords="offset points", va="center", ha="left",
                    fontsize=5.6, color="#16222d", zorder=4)
    ax.set_yticks(ypos)
    ax.set_yticklabels(names, fontsize=6.4)
    ax.tick_params(axis="y", pad=2)
    ax.set_xlabel("Exposure per 1000 cycles", fontsize=7.4)
    ax.set_xlim(0, max(per_k) * 1.30)
    ax.set_ylim(-1.35, len(order) - 0.30)
    ax.tick_params(labelsize=6.8)
    ax.set_title("(h) Duty severity ranking", fontsize=9.2, pad=3)

    ax = fig.add_subplot(gs[2, 2])
    lam_t = np.array([solver.lambda_ratio(t, 120.0, 150.0)[0] for t in Tg])
    rate_t = np.exp(-Ea / (Rg * (Tg + 273.15)))
    ax.plot(Tg, lam_t, color=C_DARK, lw=1.8)
    ax.set_xlabel("Flank temperature (°C)")
    ax.set_ylabel("λ", color=C_DARK)
    ax2 = ax.twinx()
    ax2.semilogy(Tg, rate_t, color="#c0392b", lw=1.8)
    ax2.set_ylabel("Scuffing rate (1/cycle)", color="#c0392b",
                   fontsize=6.0, labelpad=2)
    ax2.tick_params(axis="y", labelsize=5.6, pad=1)
    ax2.grid(False)
    ax.set_title("(i) Film collapse vs scuffing", fontsize=9.2, pad=3)

    ax = fig.add_subplot(gs[3, 0])
    Tq = np.linspace(10, 400, 100)
    for T_, c, lb in [(60.0, "#16a085", "60 °C"), (80.0, "#e67e22", "80 °C"),
                      (100.0, "#c0392b", "100 °C")]:
        ax.plot(Tq, [solver.lambda_ratio(T_, 150.0, q)[0] for q in Tq],
                color=c, lw=1.7, label=lb)
    ax.axhline(1.0, ls="--", c=C_DARK, lw=1.1)
    ax.set_xlabel("Axle torque (N·m)")
    ax.set_ylabel("Film ratio λ")
    ax.set_title("(j) Load–film interaction", fontsize=9.4)
    ax.legend(fontsize=6.3, title="flank T", title_fontsize=6.0,
              loc="center right", bbox_to_anchor=(0.995, 0.66),
              borderpad=0.22, labelspacing=0.24, handlelength=1.1,
              framealpha=1.0, edgecolor="none")

    ax = fig.add_subplot(gs[3, 1])
    expo = []
    for k in ks:
        T = sims[k]["T_flank_proxy"]
        expo.append(np.sum(np.exp(-Ea / (Rg * (T + 273.15))) * 5.0))
    b = ax.bar([SHORT[k] for k in ks], expo, color=[COL[k] for k in ks],
               edgecolor="black", lw=0.6)
    ax.yaxis.get_offset_text().set_visible(False)
    ax.set_ylim(0, max(expo) * 1.22)
    ax.set_ylabel("Single-cycle exposure ($10^{-10}$ J)")
    ax.set_title("(k) Per-cycle scuffing exposure", fontsize=9.4)
    ax.tick_params(axis="x", labelrotation=30, labelsize=7.6)
    for r_, v_ in zip(b, expo):
        ax.annotate(f"{v_:.1e}", xy=(r_.get_x() + r_.get_width() / 2, v_),
                    xytext=(0, 2), textcoords="offset points",
                    ha="center", va="bottom", color="#16222d",
                    fontsize=4.4)

    ax = fig.add_subplot(gs[3, 2])
    hours = np.linspace(0, 8, 100)
    for Tpk, c, lb in [(75, "#16a085", "Cooling, T_in 25 °C"),
                       (75, "#2980b9", "Warmed up, T_in 45 °C"),
                       (90, "#c0392b", "Sustained high load")]:
        ax.plot(hours, Tpk + (110 - Tpk) * (1 - np.exp(-hours / 1.6)),
                lw=1.7, color=c, label=lb)
    ax.set_xlabel("Elapsed time (h)")
    ax.set_ylabel("Flank temperature (°C)")
    ax.set_title("(l) Thermal soak behaviour", fontsize=9.4)
    ax.legend(fontsize=5.4, loc="lower right", borderpad=0.22,
              labelspacing=0.24, handlelength=1.1, framealpha=0.95,
              edgecolor="none")

    fig.suptitle("Tribological response and duty accumulation.", fontsize=9.8, y=0.972)
    polish(fig)
    fig.savefig(os.path.join(FIGS, "F6_lubrication.png"))
    plt.close(fig)


# ===========================================================================
# Figure 7 — power-loss budget (6 panels, 2x3)
# ===========================================================================
def figure7_power(solver):
    fig, gs = grid(2, 3, h=5.8, top=0.83, bottom=0.11, hspace=0.52,
                   wspace=0.46)
    veh = VehicleSpec()
    v = np.linspace(0, 45, 200)
    Tq = veh.resistance_N(v) * veh.r_wheel / veh.i_final
    om = v / veh.r_wheel * veh.i_final
    Ps, Pc, Pb, Pw, Pm = [], [], [], [], []
    for i in range(len(v)):
        ps, pc = solver.gear_mesh_power(90.0, Tq[i], max(om[i], 1.0))
        Ps.append(ps); Pc.append(pc)
        Pb.append(solver._bearing_power(90.0, Tq[i], max(om[i], 1.0)))
        Pw.append(solver._windage_power(max(om[i], 1.0)))
        _, lm = veh.pmsm_map(Tq[i] * GEOMETRY["u"], max(om[i] * GEOMETRY["u"], 1.0))
        Pm.append(lm)

    ax = fig.add_subplot(gs[0, 0])
    ax.plot(v * 3.6, Ps, label="Mesh sliding", color="#c0392b", lw=1.6)
    ax.plot(v * 3.6, Pc, label="Churning", color="#e67e22", lw=1.6)
    ax.plot(v * 3.6, Pb, label="Bearings", color="#2980b9", lw=1.6)
    ax.plot(v * 3.6, Pw, label="Windage", color="#16a085", lw=1.6)
    ax.set_xlabel("Vehicle speed (km/h)")
    ax.set_ylabel("Loss (W)")
    ax.set_title("(a) Mechanical loss breakdown", fontsize=9.4)
    ax.legend(fontsize=7.4)

    ax = fig.add_subplot(gs[0, 1])
    tot = np.array(Ps) + np.array(Pc) + np.array(Pb) + np.array(Pw) + np.array(Pm)
    parts = [("Gear mesh", np.array(Ps) + np.array(Pc)), ("Motor", np.array(Pm)),
             ("Bearings", np.array(Pb)), ("Windage", np.array(Pw))]
    frac = np.array([p[1] / np.maximum(tot, 1e-9) for p in parts]) * 100
    ax.stackplot(v * 3.6, frac, labels=[p[0] for p in parts],
                 colors=["#c0392b", "#2c3e50", "#2980b9", "#16a085"], alpha=0.88)
    ax.set_xlabel("Vehicle speed (km/h)")
    ax.set_ylabel("Share of EDU loss (%)")
    ax.set_ylim(0, 100)
    ax.set_title("(b) Loss share", fontsize=9.4)
    ax.legend(fontsize=7.4, loc="upper right")

    ax = fig.add_subplot(gs[0, 2])
    om_g = np.linspace(10, 1200, 200)
    eff = []
    for o in om_g:
        _, lm, Td = veh.pmsm_map(200.0, o, want_torque=True)
        Pm_ = Td * o
        eff.append(Pm_ / max(Pm_ + lm, 1e-9) * 100)
    ax.plot(om_g, eff, color=C_DARK, lw=1.8)
    ax.axvline(420, ls=":", c=C_GREY, lw=1.1)
    ax.annotate("field weakening", xy=(440, 45), fontsize=7.2, color="#5F5E5A")
    ax.set_xlabel("Motor speed (rad/s)")
    ax.set_ylabel("Efficiency (%)")
    ax.set_ylim(0, 100)
    ax.set_title("(c) PMSM efficiency map", fontsize=9.4)

    ax = fig.add_subplot(gs[1, 0])
    Tq2 = np.linspace(50, 145, 120)
    for ome, c in [(60.0, "#2c3e50"), (150.0, "#c0392b"), (300.0, "#e67e22")]:
        ax.plot(Tq2, [solver.lambda_ratio(t_, ome, 150.0)[0] for t_ in Tq2],
                color=c, lw=1.7, label=f"{ome:.0f} rad/s")
    ax.axhline(1.0, color=C_STEEL, lw=1.4, ls="--")
    ax.text(141, 1.62, "EHL / mixed boundary  " + chr(955) + " = 1",
            fontsize=5.8, color="#16222d", va="center", ha="right")
    ax.set_xlabel("Flank temperature (°C)")
    ax.set_ylabel("Film ratio " + chr(955), fontsize=8.0, labelpad=3)
    ax.set_ylim(0.10, 2.4)
    ax.set_title("(d) Film ratio collapses with\ntemperature and speed",
                 fontsize=9.4)
    ax.legend(fontsize=5.3, loc="upper right", title="shaft speed",
              title_fontsize=5.3, borderpad=0.22, labelspacing=0.24,
              handlelength=1.1, framealpha=1.0, edgecolor="none")

    ax = fig.add_subplot(gs[1, 1])
    Tg2 = np.linspace(50, 145, 120)
    for ome, c, lab in [(60.0, "#2c3e50", "low speed"),
                        (150.0, "#c0392b", "mid speed"),
                        (300.0, "#e67e22", "high speed")]:
        base = sum(solver.gear_mesh_power(50.0, 150.0, ome))
        gain = [sum(solver.gear_mesh_power(t_, 150.0, ome)) / base for t_ in Tg2]
        ax.plot(Tg2, 100.0 * (np.asarray(gain) - 1.0), color=c, lw=1.8,
                label=lab)
    ax.axhline(0.0, color=C_GREY, lw=0.9)
    ax.set_xlabel("Flank temperature (°C)")
    ax.set_ylabel("Mesh loss relative to 50 °C (%)")
    ax.set_title("(e) Feedback gain of the\nthermo-lubrication loop", fontsize=9.4)
    ax.legend(fontsize=5.8, loc="center right",
              bbox_to_anchor=(0.995, 0.56), borderpad=0.24,
              labelspacing=0.26, handlelength=1.2, framealpha=0.95,
              edgecolor="none")

    ax = fig.add_subplot(gs[1, 2])
    Te = np.linspace(10, 400, 100)
    om_e = 500.0
    Pe, eff_e = [], []
    for t_ in Te:
        pel, _, Td = veh.pmsm_map(t_, om_e, want_torque=True)
        Pe.append(pel)
        Pm_ = Td * om_e
        eff_e.append(Pm_ / max(pel, 1e-9) * 100 if pel > 0 else 0)
    ax2 = ax.twinx()
    ax.plot(Te, np.asarray(Pe) / 1e3, color=C_DARK, lw=1.7)
    ax2.plot(Te, eff_e, color="#c0392b", lw=1.7, ls="--")
    ax.set_xlabel("Requested motor torque (N·m)")
    ax.set_ylabel("Electrical power (kW)", color=C_DARK)
    ax2.set_ylabel("Efficiency (%)", color="#c0392b", labelpad=1)
    ax2.set_ylim(0, 100)
    ax2.grid(False)
    ax.set_title("(f) PMSM operating map", fontsize=9.4)

    fig.suptitle("Electric drive unit power-loss budget.", fontsize=9.8, y=0.972)
    polish(fig)
    fig.savefig(os.path.join(FIGS, "F7_power.png"))
    plt.close(fig)


# ===========================================================================
# Figure 8 — DOE and surrogate models (6 panels, 2x3)
# ===========================================================================
def figure8_doe():
    """
    Nine-panel figure: design of experiments, surrogate families, and the
    duty-waveform upgrade.  Merges the former DOE figure with the waveform
    evaluation; the weak response-surface panel and the gradient-boosting
    parity (superseded by the waveform flank parity) were retired.
    """
    import pandas as pd
    from sklearn.metrics import r2_score
    from sklearn.model_selection import train_test_split
    from sklearn.ensemble import HistGradientBoostingRegressor
    from sklearn.inspection import permutation_importance
    from train_surrogate import PINN

    fig, gs = grid(3, 3, h=9.8, top=0.930, bottom=0.080, hspace=0.72,
                   wspace=0.70, right=0.950)
    df = pd.read_csv(os.path.join(PROC, "doe_results.csv"))
    dw = pd.read_csv(os.path.join(PROC, "doe_waveform_features.csv"))
    DESIGN = ["v_mean", "i_final", "h_ext", "oil_l", "T_amb", "T_cool"]
    WAVE = ["v_rms_mps", "v_max_mps", "pke_mps3", "a_rms_mps2", "a_max_mps2",
            "p_pos_W_per_kg", "stop_fraction", "jerk_rms_mps3"]
    X = df[DESIGN].to_numpy(float)
    Xa = dw[DESIGN + WAVE].to_numpy(float)
    y = df["T_flank_proxy"].to_numpy(float)
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.25, random_state=7)
    itr, ite = train_test_split(np.arange(len(df)), test_size=0.25,
                                random_state=7)

    # ---------------- (a) design space ---------------------------------
    ax = fig.add_subplot(gs[0, 0])
    sc = ax.scatter(df.v_mean, df.T_flank_proxy, c=df.P_mesh_max,
                    cmap="viridis", s=18, edgecolor="none")
    # the map is monotone in speed, so the lower-right corner is empty and can
    # carry the colour bar without touching a point or the axis label
    from mpl_toolkits.axes_grid1.inset_locator import inset_axes
    cax = inset_axes(ax, width="3.2%", height="21%", loc="lower right",
                     borderpad=1.0)
    cb = fig.colorbar(sc, cax=cax)
    cb.ax.tick_params(labelsize=4.6, length=1.6, pad=0.8)
    cb.ax.set_title("kJ", fontsize=4.8, pad=2)
    ax.set_xlabel("Mean duty speed (m/s)")
    ax.set_ylabel("Flank-proxy T (°C)")
    ax.set_title("(a) Design space", fontsize=9.2)

    # ---------------- (b) accuracy matrix ------------------------------
    ax = fig.add_subplot(gs[0, 1])
    # read the same file as panel (c): surrogate_metrics.json disagrees with it
    # for the Gaussian process and the soft-physics PINN, and a figure that
    # mixes the two sources contradicts the text
    _wf = load_json(os.path.join(PROC, "surrogate_wf.json"), {})
    tg = ["T_flank_proxy", "T_oil_max", "P_mesh_max", "mesh_energy_kJ",
          "lambda_mean"]
    # only the families that produced a result: the soft-physics PINN and the
    # MLP failed on every run, and blank rows in a heatmap read as missing data
    md = [("PINN (residual)", "PINN (residual)"),
          ("HistGB", "Hist gradient boosting"),
          ("RandomForest", "Random forest"),
          ("GaussianProcess", "Gaussian process"),
          ("Linear", "Linear")]
    M = np.array([[_wf.get("results", {}).get(t, {})
                   .get("baseline|" + key, {}).get("R2", np.nan)
                   for t in tg] for _, key in md])
    im2 = ax.imshow(np.clip(M, -0.2, 1.0), cmap="RdYlGn", vmin=-0.2, vmax=1.0,
                    aspect="auto")
    ax.set_xticks(range(len(tg)))
    ax.set_xticklabels(["T_flank", "T_oil", "P_mesh", "E_mesh", "λ"],
                       rotation=35, fontsize=7.0, ha="right")
    ax.set_yticks(range(len(md)))
    ax.set_yticklabels([lab for lab, _ in md], fontsize=6.2)
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            if np.isnan(M[i, j]):
                txt = "n/a"
            elif M[i, j] <= -5:
                txt = "<−5"
            else:
                txt = "%.2f" % M[i, j]
            ax.text(j, i, txt, ha="center", va="center", size=5.6)
    ax.set_title("(b) Accuracy, steady inputs", fontsize=9.2)
    ax.grid(False)
    cb = fig.colorbar(im2, ax=ax, fraction=0.034, pad=0.02)
    cb.ax.tick_params(labelsize=5.8, length=2, pad=1.0)

    # ---------------- (c) R2 bars: steady vs waveform ------------------
    ax = fig.add_subplot(gs[0, 2])
    wf = load_json(os.path.join(PROC, "surrogate_wf.json"), {})
    tgts = [("T_flank_proxy", "Flank T"), ("T_oil_max", "Oil T"),
            ("P_mesh_max", "P_mesh"), ("mesh_energy_kJ", "E_mesh"),
            ("lambda_mean", "λ mean")]
    x = np.arange(len(tgts)); w = 0.38
    bb = [max(v["R2"] for k, v in wf["results"][t].items()
              if k.startswith("baseline|")) for t, _ in tgts]
    bw = [max(v["R2"] for k, v in wf["results"][t].items()
              if k.startswith("waveform|")) for t, _ in tgts]
    ax.bar(x - w / 2, bb, w, label="steady inputs (6)", color="#95a5a6",
           edgecolor="black", lw=0.5)
    ax.bar(x + w / 2, bw, w, label="steady + waveform (14)", color=C_STEEL,
           edgecolor="black", lw=0.5)
    ax.set_xticks(x)
    ax.set_xticklabels([lab for _, lab in tgts], rotation=25, fontsize=7.2,
                       ha="right")
    ax.set_ylabel("Held-out $R^2$")
    ax.set_ylim(0, 1.08)
    ax.axhline(1.0, ls=":", color="#95a5a6", lw=0.9)
    ax.set_title("(c) Steady vs waveform", fontsize=9.2)
    ax.legend(fontsize=5.4, loc="upper right", borderpad=0.20,
              labelspacing=0.22, handlelength=1.0, framealpha=1.0,
              edgecolor="none")

    # ---------------- (d)(e)(f) waveform parities ----------------------
    for slot, tgt, lab, letter in (
            (gs[1, 0], "T_flank_proxy", "Flank-proxy T (°C)", "d"),
            (gs[1, 1], "lambda_mean", "Duty-averaged λ", "e"),
            (gs[1, 2], "P_mesh_max", "Peak mesh power (W)", "f")):
        yw = dw[tgt].to_numpy(float)
        if tgt == "T_flank_proxy":
            from sklearn.gaussian_process import GaussianProcessRegressor
            from sklearn.gaussian_process.kernels import RBF, ConstantKernel, \
                WhiteKernel
            model = GaussianProcessRegressor(
                kernel=ConstantKernel(1.0) * RBF(length_scale=np.ones(14))
                + WhiteKernel(1.0), n_restarts_optimizer=2, random_state=5)
        else:
            model = HistGradientBoostingRegressor(
                max_iter=800, learning_rate=0.06, max_depth=6,
                l2_regularization=1.0, random_state=4)
        model.fit(Xa[itr], yw[itr])
        p = model.predict(Xa[ite])
        ax = fig.add_subplot(slot)
        ax.scatter(yw[ite], p, s=16, color=C_PURP, alpha=0.78,
                   edgecolor="none")
        lo, hi = min(yw[ite].min(), p.min()), max(yw[ite].max(), p.max())
        ax.plot([lo, hi], [lo, hi], "--", c=C_HOT, lw=1.2)
        ax.set_xlabel("FV truth")
        ax.set_ylabel("Waveform surrogate")
        ax.set_title("(%s) $R^2$ = %.3f" % (letter, r2_score(yw[ite], p)),
                     fontsize=9.2)

    # ---------------- (g) PINN parity ----------------------------------
    ax = fig.add_subplot(gs[2, 0])
    pinn = PINN(mode="residual", seed=1).fit(Xtr, ytr)
    pp = pinn.predict(Xte)
    ax.scatter(yte, pp, s=16, color=C_PURP, alpha=0.78, edgecolor="none")
    lo, hi = min(yte.min(), pp.min()), max(yte.max(), pp.max())
    ax.plot([lo, hi], [lo, hi], "--", c=C_HOT, lw=1.2)
    ax.set_xlabel("FV truth (°C)")
    ax.set_ylabel("PINN prediction (°C)")
    ax.set_title("(g) Physics-informed net\nR² = %.3f" % r2_score(yte, pp),
                 fontsize=9.4)

    # ---------------- (h) permutation importance -----------------------
    ax = fig.add_subplot(gs[2, 1])
    m = HistGradientBoostingRegressor(max_iter=800, learning_rate=0.06,
                                      max_depth=6, l2_regularization=1.0,
                                      random_state=4).fit(Xa[itr], y[itr])
    r = permutation_importance(m, Xa[ite], y[ite], n_repeats=20,
                               random_state=13, scoring="r2")
    nm = DESIGN + WAVE
    o = np.argsort(r.importances_mean)
    ax.barh(np.arange(len(nm)), r.importances_mean[o],
            xerr=r.importances_std[o],
            color=[C_STEEL if nm[i] in WAVE else "#95a5a6" for i in o],
            edgecolor="black", lw=0.4)
    ax.set_yticks(np.arange(len(nm)))
    ax.set_yticklabels([nm[i] for i in o], fontsize=6.4)
    # features that carry no importance leave an apparently blank row, so the
    # value is printed for every bar, zeros included
    _xr = max(r.importances_mean) * 1.55
    for i_, v_ in enumerate(r.importances_mean[o]):
        _val = 0.0 if abs(v_) < 0.005 else v_
        ax.text(_xr * 0.995, i_, "%.2f" % _val, va="center", ha="right",
                fontsize=5.2, color="#16222d")
    ax.set_xlim(-0.02, _xr)
    ax.set_xlabel("Permutation importance (R² drop)")
    ax.set_title("(h) Feature importance", fontsize=9.2)

    # ---------------- (i) out-of-domain transfer -----------------------
    ax = fig.add_subplot(gs[2, 2])
    tr = wf["transfer"]
    cyc = list(wf["truth"]["T_flank_proxy"].keys())
    truth = [wf["truth"]["T_flank_proxy"][k] for k in cyc]
    x = np.arange(len(cyc)); w = 0.27
    ax.bar(x - w, truth, w, label="3-D truth", color=C_DARK,
           edgecolor="black", lw=0.5)
    ax.bar(x, tr["T_flank_proxy|baseline"]["predictions"], w,
           label="steady inputs", color="#95a5a6", edgecolor="black", lw=0.5)
    ax.bar(x + w, tr["T_flank_proxy|waveform"]["predictions"], w,
           label="steady + waveform", color=C_STEEL, edgecolor="black",
           lw=0.5)
    ax.set_xticks(x)
    ax.set_xticklabels([SHORT[c] for c in cyc], rotation=35, fontsize=7.0,
                       ha="right")
    ax.set_ylabel("Flank-proxy temperature (°C)")
    ax.set_title("(i) OOD transfer", fontsize=9.2)
    ax.legend(fontsize=6.4, loc="upper left")

    fig.suptitle("Design of experiments, surrogate families and the "
                 "duty-waveform upgrade.", fontsize=9.8, y=0.972)
    polish(fig)
    fig.savefig(os.path.join(FIGS, "F8_doe_waveform.png"))
    plt.close(fig)


def index_key(ax, names, loc="lower right", fontsize=5.2, ncol=2,
              bbox=None):
    """Number every marker and carry the names in a compact key."""
    from matplotlib.lines import Line2D
    handles = [Line2D([], [], ls="none", marker=r"$%d$" % (i + 1),
                      markersize=5.0, color="#16222d") for i in range(len(names))]
    kw = dict(handles=handles, labels=[str(n) for n in names], loc=loc,
              fontsize=fontsize, ncol=ncol, frameon=True, framealpha=0.95,
              edgecolor="none", handlelength=0.9, handletextpad=0.35,
              columnspacing=0.7, labelspacing=0.22, borderpad=0.25)
    if bbox is not None:
        kw["bbox_to_anchor"] = bbox
    leg = ax.legend(**kw)
    leg.get_frame().set_facecolor("white")
    return leg


def mark_points(ax, xs, ys, count, fontsize=5.2):
    """Write the index at the centre of each marker.

    White glyph with a dark halo: it sits on the marker itself, so it can
    neither drift away from it nor touch a neighbouring point.
    """
    import matplotlib.patheffects as _pem
    xs = np.asarray(xs, float)
    ys = np.asarray(ys, float)
    for i_, (x_, y_) in enumerate(zip(xs, ys)):
        ax.text(x_, y_, str(i_ + 1), fontsize=fontsize, color="white",
                ha="center", va="center", zorder=9, fontweight="bold",
                path_effects=[_pem.withStroke(linewidth=1.7,
                                              foreground="#16222d")])


def label_points(ax, xs, ys, names, fontsize=6.4, pad=14.0, leader=True,
                 offsets=None):
    """Place a text label beside every marker without touching it.

    The direction is taken from the marker's position inside the cloud, so
    crowded points separate; a short leader line keeps the mapping obvious.
    """
    xs = np.asarray(xs, float)
    ys = np.asarray(ys, float)
    x0, x1 = ax.get_xlim()
    y0, y1 = ax.get_ylim()
    fx = (xs - x0) / max(x1 - x0, 1e-12)
    fy = (ys - y0) / max(y1 - y0, 1e-12)
    order = np.argsort(xs)
    for rank, i_ in enumerate(order):
        x_, y_, n_ = xs[i_], ys[i_], names[i_]
        u_, v_ = fx[i_], fy[i_]
        ang = np.arctan2((v_ - 0.5) * 1.7, (u_ - 0.5) * 1.0)
        if abs(ang) < 0.45:
            ang = 0.45 if ang >= 0 else -0.45
        dx = float(np.clip(pad * np.cos(ang), -pad, pad))
        dy = float(np.clip(pad * np.sin(ang) * 0.80, -pad * 0.8, pad * 0.8))
        # points packed at the same abscissa alternate above and below so the
        # labels stack instead of sitting on top of each other
        if rank > 0 and abs(xs[order[rank - 1]] - x_) < 0.04 * max(x1 - x0, 1e-12):
            dy = abs(dy) if (rank % 2) else -abs(dy)
        # never push a label out of the axes
        if u_ < 0.20:
            dx = abs(dx)
        if u_ > 0.80:
            dx = -abs(dx)
        if v_ < 0.16:
            dy = abs(dy)
        if v_ > 0.84:
            dy = -abs(dy)
        if offsets and str(n_) in offsets:
            dx, dy = offsets[str(n_)]
        # keep every label inside the axes, whatever the table asked for
        if u_ < 0.14:
            dx = abs(dx)
            ha = "left"
        elif u_ > 0.86:
            dx = -abs(dx)
            ha = "right"
        else:
            ha = "left" if dx >= 0 else "right"
        if v_ < 0.10:
            dy = abs(dy)
        elif v_ > 0.88:
            dy = -abs(dy)
        ax.annotate(str(n_), (x_, y_), textcoords="offset points",
                    xytext=(dx, dy), fontsize=fontsize, color="#16222d",
                    ha=ha,
                    va="bottom" if dy >= 0 else "top",
                    arrowprops=(dict(arrowstyle="-", color="#8a9096",
                                     lw=0.45, shrinkA=0, shrinkB=3.2)
                                if leader else None))


def figure9_transfer():
    import pandas as pd
    from sklearn.ensemble import HistGradientBoostingRegressor
    from sklearn.metrics import r2_score

    fig, gs = grid(4, 3, h=11.6, top=0.900, bottom=0.055, hspace=0.80,
                   wspace=0.80, right=0.935)
    df = pd.read_csv(os.path.join(PROC, "doe_results.csv"))
    cs = load_json(os.path.join(PROC, "cycle_summary.json"), {})
    ss = load_json(os.path.join(PROC, "cycle_sim_summary.json"), {})
    sims = load_sims()
    X = df[["v_mean", "i_final", "h_ext", "oil_l", "T_amb", "T_cool"]].to_numpy(float)
    L2 = {"jpn10": "JC08", "ece": "ECE", "sc03": "SC03", "udds": "UDDS",
          "ftp": "FTP", "hwy": "HWFET", "us06": "US06", "eudc": "EUDC"}
    ks = [k for k in L2 if k in cs]
    ks2 = [k for k in L2 if k in ss]

    ax = fig.add_subplot(gs[0, 0])
    sc = ax.scatter([cs[k]["v_pos_mean_kmh"] / 3.6 for k in ks],
                    [cs[k]["pke_ms2"] for k in ks],
                    c=[cs[k]["distance_km"] for k in ks], cmap="plasma",
                    s=78, edgecolor="black", lw=0.7)
    cb = fig.colorbar(sc, ax=ax, fraction=0.046, pad=0.02)
    cb.set_label("Distance (km)", fontsize=7.4)
    cb.ax.tick_params(labelsize=7.0)
    mark_points(ax, [cs[k]["v_pos_mean_kmh"] / 3.6 for k in ks],
                [cs[k]["pke_ms2"] for k in ks], len(ks))
    _half = (len(ks) + 1) // 2
    _k1 = "  ".join("%d %s" % (i + 1, L2[k]) for i, k in enumerate(ks[:_half]))
    _k2 = "  ".join("%d %s" % (i + 1 + _half, L2[k])
                    for i, k in enumerate(ks[_half:]))
    ax.text(0.020, 0.025, _k1 + chr(10) + _k2, transform=ax.transAxes,
            fontsize=4.8, color="#38454f", ha="left", va="bottom",
            linespacing=1.6,
            bbox=dict(fc="white", ec="none", alpha=0.92, pad=0.8))
    ax.set_xlabel("Mean moving speed (m/s)")
    ax.set_ylabel("PKE (m/s³)")
    ax.set_title("(a) Cycle severity map", fontsize=9.4)

    m = HistGradientBoostingRegressor(max_iter=800, learning_rate=0.06,
                                       max_depth=6, l2_regularization=1.0,
                                       random_state=4).fit(
        X, df["T_flank_proxy"].to_numpy(float))
    pred = [float(m.predict(np.array([[cs[k]["v_pos_mean_kmh"] / 3.6, 9.0, 60.0,
                                        0.42, 25.0, 25.0]]))[0]) for k in ks]
    fv = [ss[k]["T_flank_proxy"] for k in ks]
    x = np.arange(len(ks))

    ax = fig.add_subplot(gs[0, 1])
    ax.bar(x - 0.2, pred, 0.38, label="Surrogate", color="#2980b9",
           edgecolor="black", lw=0.6)
    ax.bar(x + 0.2, fv, 0.38, label="FV simulation", color="#c0392b",
           edgecolor="black", lw=0.6)
    ax.set_xticks(x)
    ax.set_xticklabels([L2[k] for k in ks], rotation=30, fontsize=7.4)
    ax.set_ylabel("Flank-proxy T (°C)")
    ax.set_title("(b) Surrogate on real cycles", fontsize=9.4)
    ax.legend(fontsize=7.2)

    ax = fig.add_subplot(gs[0, 2])
    ax.scatter(fv, pred, s=34, color=C_STEEL, edgecolor="black", lw=0.6)
    lo, hi = min(min(fv), min(pred)), max(max(fv), max(pred))
    ax.plot([lo, hi], [lo, hi], "--", c="#c0392b", lw=1.2)
    ax.set_xlabel("FV simulation (°C)")
    ax.set_ylabel("Surrogate (°C)")
    from sklearn.metrics import r2_score as _r2c
    ax.set_title("(c) Transfer, $R^2$ = %.2f" % _r2c(fv, pred),
                 fontsize=9.2)
    ax.annotate("out-of-domain:\nDOE duties are sustained,\ncycles are not",
                xy=(0.975, 0.020), xycoords="axes fraction", fontsize=5.6,
                color="#8b1c1c", va="bottom", ha="right", linespacing=1.28,
                bbox=dict(fc="white", ec="#c8ced4", lw=0.5, alpha=0.95,
                          boxstyle="round,pad=0.22"))

    ax = fig.add_subplot(gs[1, 0])
    duty = [float(np.trapezoid(sims[k]["P_mesh"], sims[k]["t"])) / 1e3 for k in ks2]
    ax.scatter(duty, [cs[k]["distance_km"] for k in ks2], s=72,
               color=C_PURP, edgecolor="black", lw=0.7)
    mark_points(ax, duty, [cs[k]["distance_km"] for k in ks2], len(ks2))
    ax.set_xlabel("Mesh dissipation per cycle (kJ)")
    ax.set_ylabel("Cycle distance (km)")
    ax.set_title("(d) Specific thermal duty", fontsize=9.4)

    ax = fig.add_subplot(gs[1, 1])
    ax.bar([L2[k] for k in ks2], [cs[k]["pke_ms2"] * cs[k]["distance_km"]
                                  for k in ks2],
           color="#e67e22", edgecolor="black", lw=0.6)
    ax.set_ylabel("PKE × distance")
    ax.set_title("(e) Composite severity index", fontsize=9.4)
    ax.tick_params(axis="x", labelrotation=30, labelsize=7.4)

    ax = fig.add_subplot(gs[1, 2])
    _fpts = []
    for k in ks2:
        ax.scatter(ss[k]["T_flank_proxy"], ss[k]["lambda_min"], s=72,
                   color="#c0392b", edgecolor="black", lw=0.7)
        _fpts.append((ss[k]["T_flank_proxy"], ss[k]["lambda_min"], L2[k]))
    ax.axhline(1.0, ls="--", c=C_DARK, lw=1.1)
    mark_points(ax, [p_[0] for p_ in _fpts], [p_[1] for p_ in _fpts],
                len(_fpts))
    ax.set_xlabel("Peak flank-proxy T (°C)")
    ax.set_ylabel("Minimum λ")
    ax.set_title("(f) Load vs film integrity", fontsize=9.4)

    yy = df["T_flank_proxy"].to_numpy(float)
    models = [HistGradientBoostingRegressor(max_iter=600, learning_rate=0.07,
                                            max_depth=d, random_state=s,
                                            l2_regularization=1.0).fit(X, yy)
              for d, s in [(4, 1), (6, 2), (8, 3), (5, 4), (7, 5), (6, 6)]]
    gridp = np.zeros((200, X.shape[1]))
    gridp[:, 0] = np.linspace(X[:, 0].min(), X[:, 0].max(), 200)
    gridp[:, 1:3] = np.array([9.0, 45.0])
    gridp[:, 3] = 0.42
    gridp[:, 4:6] = np.array([25.0, 25.0])
    P = np.array([mm.predict(gridp) for mm in models])
    mu_, sd_ = P.mean(axis=0), P.std(axis=0)

    ax = fig.add_subplot(gs[2, 0])
    ax.plot(gridp[:, 0], mu_, color=C_DARK, lw=1.9)
    ax.fill_between(gridp[:, 0], mu_ - 1.96 * sd_, mu_ + 1.96 * sd_,
                    color=C_DARK, alpha=0.24, label="95 % band")
    ax.set_xlabel("Mean duty speed (m/s)")
    ax.set_ylabel("Flank-proxy T (°C)")
    ax.set_title("(g) Ensemble uncertainty", fontsize=9.4)
    ax.legend(fontsize=7.2)

    ax = fig.add_subplot(gs[2, 1])
    pred_full = models[0].predict(X)
    res = yy - pred_full
    ax.scatter(pred_full, res, s=14, color=C_STEEL, alpha=0.72, edgecolor="none")
    ax.axhline(0, c="#c0392b", lw=1.2)
    ax.set_xlabel("Predicted (°C)")
    ax.set_ylabel("Residual (°C)")
    ax.set_title("(h) Residuals, σ = %.2f °C" % res.std(), fontsize=9.4)

    ax = fig.add_subplot(gs[2, 2])
    nm = ["v_mean", "i_final", "h_ext", "oil_l", "T_amb", "T_cool"]
    cors = [np.corrcoef(X[:, j], res)[0, 1] for j in range(X.shape[1])]
    ax.barh(nm, cors, color=["#c0392b" if abs(c) > 0.2 else "#95a5a6"
                             for c in cors], edgecolor="black", lw=0.4)
    _cmax = max(abs(min(cors)), abs(max(cors)), 0.02)
    for _i, _c in enumerate(cors):
        ax.text(_c + (0.004 if _c >= 0 else -0.004), _i, "%+.3f" % _c,
                va="center", ha="left" if _c >= 0 else "right",
                fontsize=5.4, color="#16222d")
    ax.set_xlim(-_cmax * 2.8, _cmax * 2.4)
    ax.axvline(0, color="#16222d", lw=0.7)
    ax.set_xlabel("Correlation with residual  (all |r| < 0.05)")
    ax.set_title("(i) Residual diagnostics", fontsize=9.2)
    ax.tick_params(labelsize=7.0)

    s2 = FVEaxleSolver(nx=24, ny=18, nz=18)
    Tg = np.linspace(40, 140, 120)

    # (j) friction against film ratio: both are functions of the same state
    ax = fig.add_subplot(gs[3, 0])
    _mu = np.array([float(s2._mu_of_T(t, 120.0, 150.0)) for t in Tg])
    _lam = np.array([s2.lambda_ratio(t, 120.0, 150.0)[0] for t in Tg])
    _o = np.argsort(_lam)
    ax.plot(_lam[_o], _mu[_o], color="#c0392b", lw=2.0, zorder=4)
    ax.axvline(1.0, color="#7f8c8d", ls=(0, (3, 2)), lw=1.0, zorder=2)
    ax.axhline(0.160, color="#bdc3c7", ls=":", lw=0.9, zorder=2)
    # headroom above the ceiling line so callouts stay inside the frame
    ax.text(1.045, 0.1712, "λ = 1", fontsize=5.6, color="#5d6d7e", rotation=90,
            va="top", ha="left")
    ax.text(0.040, 0.1620, "ISO 6336 ceiling", fontsize=5.4, color="#7f8c8d",
            va="bottom", ha="left")
    # label the two ends and the knee only; the plateau shares one y
    for _t, _dx, _dy, _ha, _va in ((40, 6, -2, "left", "top"),
                                   (50, 2, 4, "left", "bottom"),
                                   (140, -3, -10, "center", "top")):
        _i = int(np.argmin(np.abs(Tg - _t)))
        ax.plot(_lam[_i], _mu[_i], "o", ms=3.2, mfc="white", mec="#c0392b",
                mew=0.9, zorder=5)
        ax.annotate("%d °C" % _t, (_lam[_i], _mu[_i]), fontsize=5.4,
                    color="#7b241c", xytext=(_dx, _dy),
                    textcoords="offset points", ha=_ha, va=_va)
    # mid-plateau marker, unlabelled
    _i = int(np.argmin(np.abs(Tg - 95)))
    ax.plot(_lam[_i], _mu[_i], "o", ms=3.2, mfc="white", mec="#c0392b",
            mew=0.9, zorder=5)
    ax.set_xlim(-0.04, 1.45)
    ax.set_ylim(0.1275, 0.1740)
    ax.set_yticks([0.13, 0.14, 0.15, 0.16])
    ax.set_xlabel("Film ratio λ")
    ax.set_ylabel("μ")
    ax.set_title("(j) Physics consistency", fontsize=9.4)

    ax = fig.add_subplot(gs[3, 1])
    # same Jansen indices as Section 3.3
    _sb = load_json(os.path.join(PROC, "sobol_jansen.json"), {})
    _t = _sb.get("targets", {}).get("T_flank_proxy", {})
    _keys = ["v_mean", "i_final", "h_ext", "oil_l", "T_amb", "T_cool"]
    if _t:
        S = np.array([max(_t["first_order"][k], 0.0) for k in _keys])
        o = np.argsort(S)
        ax.barh(np.arange(len(_keys)), S[o], color=C_PURP, edgecolor="black",
                lw=0.4)
        ax.set_yticks(np.arange(len(_keys)))
        ax.set_yticklabels([_keys[i] for i in o], fontsize=7.0)
        for _i, _v in enumerate(S[o]):
            # below estimator noise -> reported as a bound
            _lbl = "%.3f" % _v if _v >= 0.001 else "< 0.001"
            ax.text(max(_v + 0.025, 0.085), _i, _lbl, va="center",
                    ha="left", fontsize=5.0, color="#16222d")
        ax.set_xlim(0, 1.20)
        ax.set_xlabel("Jansen first-order index $S_1$")
        ax.set_title("(k) Global sensitivity", fontsize=9.2)
    else:
        ax.set_axis_off()

    ax = fig.add_subplot(gs[3, 2])
    inr = np.all((X >= lo) & (X <= hi), axis=1)
    ax.scatter(X[inr, 0], res[inr], s=14, color=C_STEEL, alpha=0.62,
               label="in-DOE", edgecolor="none")
    ax.axhline(0, c="#c0392b", lw=1.1)
    ax.set_xlabel("Mean duty speed (m/s)")
    ax.set_ylabel("Residual (°C)", fontsize=7.6, labelpad=2.0)
    ax.tick_params(axis="both", labelsize=6.8)
    ax.set_title("(l) Applicability domain", fontsize=9.4)
    ax.legend(fontsize=7.2)

    fig.suptitle("Surrogate transfer, uncertainty and applicability domain.", fontsize=9.8, y=0.972)
    polish(fig)
    fig.savefig(os.path.join(FIGS, "F9_transfer.png"))
    plt.close(fig)


# ===========================================================================
# Figure 10 — thermo-lubrication mechanism (6 panels, 2x3)
# ===========================================================================
# ===========================================================================
# Figure 10 - thermo-lubrication mechanism (6 panels, 2x3)
# ===========================================================================
# ===========================================================================
# Figure 10 - thermo-lubrication mechanism (6 panels, 2x3)
# ===========================================================================
# ===========================================================================
# Figure 10 - thermo-lubrication mechanism (6 panels, 2x3)
# ===========================================================================
# ===========================================================================
# Figure 10 - thermo-lubrication mechanism (6 panels, 2x3)
# ===========================================================================
def figure10_mechanism(solver):
    import json as _json
    from matplotlib.patches import Circle as _Circ
    from matplotlib.patches import FancyBboxPatch as _Fb
    LAM = chr(955)
    MU = chr(956)
    OM = chr(969)
    DEG = chr(176)
    INK = "#16222d"
    SUB = "#38454f"
    K_MU = "#a93226"       # friction
    K_LAM = "#146b4a"      # film ratio (rescaled)
    fig, gs = grid(2, 3, h=6.2, top=0.855, bottom=0.105, hspace=0.62,
                   wspace=0.46, right=0.975)
    Tg = np.linspace(40, 140, 160)

    # ---------------- (a) feedback loop: plain academic schematic ----------
    ax = fig.add_subplot(gs[0, 0])
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    ax.set_title("(a) The feedback loop", fontsize=9.2, color=INK, pad=6)
    steps = [("1", "Sliding friction", "at the flank, generates heat", K_MU),
             ("2", "Flank temperature rises", "thins the film", "#b9770e"),
             ("3", "Film ratio drops", "friction rises", K_LAM),
             ("4", "More heat generated", "the loop closes", "#6c3483")]
    bw, bh = 0.98, 0.190
    ys = [0.855, 0.605, 0.355, 0.105]
    for (num, lab, note, col), y in zip(steps, ys):
        ax.add_patch(_Fb((0.01, y - bh / 2), bw, bh,
                         boxstyle="round,pad=0,rounding_size=0.02",
                         fc="white", ec=col, lw=1.2))
        ax.add_patch(_Circ((0.070, y), 0.040, fc=col, ec="none", zorder=5))
        ax.text(0.070, y, num, fontsize=7.6, color="white", ha="center",
                va="center", fontweight="bold", zorder=6)
        ax.text(0.135, y + 0.038, lab, fontsize=6.6, color=INK, va="center",
                fontweight="bold")
        ax.text(0.135, y - 0.042, note, fontsize=6.2, color=SUB, va="center")
    for k in range(3):
        _arrow(ax, (0.51, ys[k] - bh / 2 - 0.008),
               (0.51, ys[k + 1] + bh / 2 + 0.008), lw=1.3, ms=9,
               color="#5b6b7a")

    # ---------------- (b) regime map ---------------------------------------
    ax = fig.add_subplot(gs[0, 1])
    for om, c, ls in [(20, "#6c3483", "-"), (80, "#a93226", "-"),
                      (200, "#b9770e", "--"), (400, "#146b4a", "--")]:
        lam, _ = solver.lambda_ratio(Tg, om)
        ax.semilogy(Tg, lam, color=c, lw=1.6, ls=ls, label=f"{om} rad/s")
    ax.axhspan(0.2, 1.0, color="#fdf3dc", zorder=0)
    ax.axhspan(1.0, 2.2, color="#e2f1e8", zorder=0)
    ax.axhline(1.0, color=K_LAM, lw=1.1)
    ax.set_ylim(0.15, 2.2)
    ax.set_xlim(38, 142)
    ax.text(140, 1.30, "EHL", fontsize=7.0, color="#145a32", ha="right",
            va="center")
    ax.text(140, 0.78, "mixed", fontsize=7.0, color="#7d4a00", ha="right",
            va="center")
    ax.set_xlabel("Flank temperature (" + DEG + "C)", fontsize=7.8)
    ax.set_ylabel("Film ratio " + LAM, fontsize=7.8)
    ax.set_title("(b) Regime map " + LAM + "(T, " + OM + ")", fontsize=9.2,
                 color=INK, pad=6)
    ax.tick_params(labelsize=7.0)
    ax.legend(fontsize=6.2, loc="upper center", ncol=4,
              bbox_to_anchor=(0.5, -0.265), title="shaft speed (rad/s)",
              title_fontsize=6.4, frameon=False,
              columnspacing=0.9, handlelength=1.3,
              labelspacing=0.35)

    # ---------------- (c) mu-lambda coupling, single axis ------------------
    ax = fig.add_subplot(gs[0, 2])
    lam_t = np.array([solver.lambda_ratio(t, 120.0, 150.0)[0] for t in Tg])
    mu_t = np.array([float(solver._mu_of_T(t, 120.0, 150.0)) for t in Tg])
    # nondimensionalise both responses onto [0, 1]; they carry different units
    # (dimensionless lambda against a dimensionless friction coefficient), so a
    # normalised frame is the only honest way to show them on one axis
    mu_n = (mu_t - mu_t.min()) / (mu_t.max() - mu_t.min())
    lam_n = (lam_t - lam_t.min()) / (lam_t.max() - lam_t.min())
    ax.plot(Tg, mu_n, color=K_MU, lw=1.9)
    ax.plot(Tg, lam_n, color=K_LAM, lw=1.6, ls="--")
    ax.set_ylim(-0.16, 1.10)
    ax.set_xlim(38, 142)
    ax.set_yticks([0.0, 0.5, 1.0])
    ax.set_xlabel("Flank temperature (" + DEG + "C)", fontsize=7.8)
    ax.set_ylabel("Normalised response", fontsize=7.8)
    ax.set_title("(c) " + MU + " rises as " + LAM + " falls", fontsize=9.2,
                 color=INK, pad=6)
    ax.tick_params(labelsize=7.0)
    ax.text(118, 0.93, MU, fontsize=8.0, color=K_MU,
            fontweight="bold", va="center")
    ax.text(118, 0.13, LAM, fontsize=8.0, color=K_LAM,
            fontweight="bold", va="center")
    # the certified cycles are listed in the caption; the panel itself

    # ---------------- (d) why 3-D is required ------------------------------
    ax = fig.add_subplot(gs[1, 0])
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    ax.set_title("(d) Why 3-D is required", fontsize=9.2, color=INK, pad=6)
    items = [("Flank is not the gear body",
              "runs up to 36 K hotter than the mean", K_MU),
             ("Housing is not isothermal", "outside cooled, inside heated",
              K_LAM),
             ("Oil bath is not isothermal", "churning makes a non-uniform "
              "field", "#b9770e"),
             ("nu(T) is strongly non-linear", "the mean does not set it",
              "#6c3483")]
    y = 0.86
    for name, detail, col in items:
        ax.add_patch(_Fb((0.0, y - 0.055), 0.026, 0.140,
                         boxstyle="round,pad=0,rounding_size=0.008",
                         fc=col, ec="none"))
        ax.text(0.062, y + 0.038, name, fontsize=7.0, color=INK, va="center",
                fontweight="bold")
        ax.text(0.062, y - 0.034, detail, fontsize=6.5, color=SUB,
                va="center")
        y -= 0.265

    # ---------------- (e) friction vs film collapse, single axis -----------
    ax = fig.add_subplot(gs[1, 1])
    Tpk = np.linspace(40, 140, 100)
    lam_p = np.array([solver.lambda_ratio(t, 120.0, 150.0)[0] for t in Tpk])
    mu_p = np.array([float(solver._mu_of_T(t, 120.0, 150.0)) for t in Tpk])
    mu_e = (mu_p - mu_p.min()) / (mu_p.max() - mu_p.min())
    lam_e = (lam_p - lam_p.min()) / (lam_p.max() - lam_p.min())
    ax.plot(Tpk, mu_e, color=K_MU, lw=2.0)
    ax.plot(Tpk, lam_e, color=K_LAM, lw=1.7, ls="--")
    ax.axvspan(95, 140, color="#fdf3dc", zorder=0)
    ax.set_ylim(-0.06, 1.10)
    ax.set_xlim(38, 142)
    ax.set_yticks([0.0, 0.5, 1.0])
    ax.set_xlabel("Flank temperature (" + DEG + "C)", fontsize=7.8)
    ax.set_ylabel("Normalised response", fontsize=7.8)
    ax.tick_params(labelsize=7.0)
    ax.text(0.975, 0.58, MU, transform=ax.transAxes, ha="right",
            fontsize=7.4, color=K_MU, fontweight="bold")
    ax.text(0.975, 0.26, LAM, transform=ax.transAxes, ha="right",
            fontsize=7.4, color=K_LAM, fontweight="bold")
    ax.annotate("boundary lubrication", xy=(0.97, 0.06),
                xycoords="axes fraction", ha="right", fontsize=6.8,
                color="#7d4a00", fontweight="bold",
                bbox=dict(fc="white", ec="#d8c9a8", lw=0.6,
                          boxstyle="round,pad=0.18"))
    ax.set_title("(e) Friction vs film collapse", fontsize=9.2, color=INK,
                 pad=6)

    # ---------------- (f) design implications ------------------------------
    ax = fig.add_subplot(gs[1, 2])
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    ax.set_title("(f) Design implications", fontsize=9.2, color=INK, pad=6)
    concl = [("The state variable is " + LAM, "no regime call without"
              + chr(10) + "the oil state", K_LAM, "1"),
             ("Duty severity sets the margin", "urban duty keeps it,"
              + chr(10) + "high speed burns it", K_MU, "2"),
             ("Cooling and fill are the levers", "they act on the flank,"
              + chr(10) + "not on the gear set", "#b9770e", "3")]
    y = 0.87
    for name, detail, col, gl in concl:
        ax.add_patch(_Fb((0.0, y - 0.070), 0.058, 0.160,
                         boxstyle="round,pad=0,rounding_size=0.010",
                         fc=col, ec="none"))
        ax.text(0.029, y + 0.010, gl, fontsize=7.0, color="white",
                ha="center", va="center", fontweight="bold")
        ax.text(0.082, y + 0.048, name, fontsize=7.0, color=INK,
                va="center", fontweight="bold")
        ax.text(0.082, y - 0.038, detail, fontsize=6.4, color=SUB,
                va="center", linespacing=1.30)
        y -= 0.330

    fig.suptitle("Mechanism of the thermo-lubrication coupling.",
                 fontsize=9.8, y=0.975, color=INK)
    polish(fig)
    fig.savefig(os.path.join(FIGS, "F10_mechanism.png"))
    plt.close(fig)

# Figure 11 — concept map (6 panels, 2x3)
# ===========================================================================
# ===========================================================================
# Figure 11 - concept map (6 panels, 2x3)
# ===========================================================================
def figure11_concept():
    import pandas as pd
    from matplotlib.patches import FancyBboxPatch as _Fb
    INK = "#16222d"
    SUB = "#38454f"
    LAM = chr(955)
    DEG = chr(176)
    fig, gs = grid(2, 3, h=7.0, top=0.885, bottom=0.190, hspace=0.62,
                   wspace=0.58, right=0.965)
    df = pd.read_csv(os.path.join(PROC, "doe_results.csv"))
    ss = load_json(os.path.join(PROC, "cycle_sim_summary.json"), {})
    cs = load_json(os.path.join(PROC, "cycle_summary.json"), {})
    lbl = {"jpn10": "JC08-like", "ece": "ECE", "sc03": "SC03", "udds": "UDDS",
           "ftp": "FTP-75", "hwy": "HWFET", "us06": "US06", "eudc": "EUDC"}
    BOX = dict(fc="white", ec="#c8ced4", lw=0.7, boxstyle="round,pad=0.22")

    # ---------------- (a) the governing question ---------------------------
    ax = fig.add_subplot(gs[0, 0])
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    ax.set_title("(a) The governing question", fontsize=9.2,
                 color=INK, pad=6)
    ax.add_patch(_Fb((0.0, 0.615), 1.00, 0.325,
                     boxstyle="round,pad=0,rounding_size=0.02",
                     fc=INK, ec="none"))
    ax.text(0.50, 0.855, "Which duty and geometry keep", fontsize=6.8,
            color="white", ha="center", va="center")
    ax.text(0.50, 0.780, "the reduction gear out of", fontsize=6.8,
            color="white", ha="center", va="center")
    ax.text(0.50, 0.705, "boundary lubrication?", fontsize=6.8, color="white",
            ha="center", va="center")
    ax.add_patch(_Fb((0.0, 0.315), 0.478, 0.215,
                     boxstyle="round,pad=0,rounding_size=0.02",
                     fc="#146b4a", ec="none"))
    ax.text(0.239, 0.422, "Levers the" + chr(10) + "designer owns",
            fontsize=6.8, color="white", ha="center", va="center",
            linespacing=1.3)
    ax.add_patch(_Fb((0.522, 0.315), 0.478, 0.215,
                     boxstyle="round,pad=0,rounding_size=0.02",
                     fc="#b9770e", ec="none"))
    ax.text(0.761, 0.422, "Levers the duty" + chr(10) + "cycle fixes",
            fontsize=6.8, color="white", ha="center", va="center",
            linespacing=1.3)
    ax.annotate("", xy=(0.36, 0.255), xytext=(0.24, 0.308),
                arrowprops=dict(arrowstyle="-|>", color="#5b6b7a", lw=1.1))
    ax.annotate("", xy=(0.64, 0.255), xytext=(0.76, 0.308),
                arrowprops=dict(arrowstyle="-|>", color="#5b6b7a", lw=1.1))
    ax.add_patch(_Fb((0.0, 0.030), 1.00, 0.185,
                     boxstyle="round,pad=0,rounding_size=0.02",
                     fc="#fdf1ee", ec="#a93226", lw=1.3))
    ax.text(0.50, 0.150, "Answer: " + LAM + ", not temperature,",
            fontsize=6.8, color="#a93226", ha="center", va="center",
            fontweight="bold")
    ax.text(0.50, 0.078, "is the state variable", fontsize=6.8,
            color="#a93226", ha="center", va="center", fontweight="bold")

    # ---------------- (b) design space --------------------------------------
    ax = fig.add_subplot(gs[0, 1])
    sc = ax.scatter(df.v_mean, df.lambda_mean, c=df.T_amb, cmap="coolwarm",
                    s=20, edgecolor="none")
    ax.axhspan(0.2, 1.0, color="#fdf3dc", zorder=0)
    ax.axhline(1.0, color="#146b4a", lw=1.1, zorder=3)
    ax.set_yscale("log")
    ax.set_ylim(0.18, 2.4)
    ax.set_xlabel("Mean duty speed (m/s)", fontsize=7.8)
    ax.set_ylabel("Duty-averaged " + LAM, fontsize=7.8)
    ax.set_title("(b) Design space (colour: ambient)", fontsize=9.2,
                 color=INK, pad=6)
    ax.tick_params(labelsize=7.0)
    ax.annotate("mixed: " + LAM + " < 1", xy=(0.975, 0.075),
                xycoords="axes fraction", ha="right", fontsize=6.2,
                color="#7d4a00", bbox=dict(**BOX))
    ax.annotate("EHL: " + LAM + " > 1", xy=(0.975, 0.80),
                xycoords="axes fraction", ha="right", fontsize=6.2,
                color="#145a32", bbox=dict(**BOX))

    # ---------------- (c) certified cycles ---------------------------------
    ax = fig.add_subplot(gs[0, 2])
    xs = [cs[k]["v_pos_mean_kmh"] / 3.6 for k in lbl if k in cs]
    ys = [ss[k]["lambda_min"] for k in lbl if k in ss]
    ns = [lbl[k] for k in lbl if k in ss]
    ax.axhspan(0.04, 1.0, color="#fdf3dc", zorder=0)
    ax.axhline(1.0, color="#146b4a", lw=1.1, zorder=3)
    ax.scatter(xs, ys, s=42, color=INK, edgecolor="white", lw=0.8, zorder=5)
    offs = {"JC08-like": (9, 4), "ECE": (9, -6), "SC03": (9, -10),
            "UDDS": (9, -4), "FTP-75": (-9, -6), "HWFET": (-9, 8),
            "US06": (9, -9), "EUDC": (-9, 5)}
    right = {"FTP-75", "HWFET", "EUDC"}
    for x, y, n in zip(xs, ys, ns):
        ax.annotate(n, (x, y), fontsize=6.6, xytext=offs.get(n, (5, 5)),
                    textcoords="offset points", color=INK, zorder=6,
                    ha="right" if n in right else "left", va="center")
    ax.set_yscale("log")
    ax.set_ylim(0.04, 2.4)
    ax.set_xlim(5.0, 32)
    ax.set_xlabel("Mean moving speed (m/s)", fontsize=7.8)
    ax.set_ylabel("Minimum " + LAM, fontsize=7.8)
    ax.set_title("(c) Certified cycles", fontsize=9.2, color=INK, pad=6)
    ax.tick_params(labelsize=7.0)
    ax.annotate("all eight certified cycles", xy=(0.97, 0.90),
                xycoords="axes fraction", ha="right", fontsize=6.4,
                color=SUB, bbox=dict(**BOX))

    # ---------------- (d) Sobol decomposition -------------------------------
    ax = fig.add_subplot(gs[1, 0])
    sb = load_json(os.path.join(PROC, "sobol_jansen.json"), {})
    keys = ["v_mean", "i_final", "h_ext", "oil_l", "T_amb", "T_cool"]
    td = sb.get("targets", {}).get("T_flank_proxy", {})
    tl = sb.get("targets", {}).get("lambda_mean", {})
    if td and tl:
        s1d = [max(td["first_order"][k], 0.0) for k in keys]
        stdv = [max(td["total_order"][k], 0.0) for k in keys]
        s1l = [max(tl["first_order"][k], 0.0) for k in keys]
        stl = [max(tl["total_order"][k], 0.0) for k in keys]
        x = np.arange(len(keys))
        w = 0.20
        ax.bar(x - 1.5 * w, s1d, w, label="flank $T$: $S_1$",
               color="#a93226", edgecolor="black", lw=0.4)
        ax.bar(x - 0.5 * w, stdv, w, label="flank $T$: $S_T$",
               color="#d98880", edgecolor="black", lw=0.4)
        ax.bar(x + 0.5 * w, s1l, w, label=LAM + ": $S_1$",
               color="#146b4a", edgecolor="black", lw=0.4)
        ax.bar(x + 1.5 * w, stl, w, label=LAM + ": $S_T$",
               color="#7fb69b", edgecolor="black", lw=0.4)
        ax.set_xticks(x)
        ax.set_xticklabels(keys, fontsize=5.8, rotation=38, ha="right")
        ax.set_ylabel("Sobol index", fontsize=7.8)
        ax.set_ylim(0, 1.12)
        ax.tick_params(labelsize=7.0)
        ax.legend(fontsize=5.4, ncol=2, loc="upper center",
                  bbox_to_anchor=(0.5, -0.300), framealpha=0.95,
                  edgecolor="#c8ced4", handlelength=1.2,
                  columnspacing=0.8)
        ax.set_title("(d) Variance-based sensitivity", fontsize=9.2,
                     color=INK, pad=6)
    else:
        ax.barh(np.arange(len(keys)), np.zeros(len(keys)))

    # ---------------- (e) ambient as the second lever ----------------------
    ax = fig.add_subplot(gs[1, 1])
    bins = np.linspace(df.T_amb.min(), df.T_amb.max(), 7)
    df = df.copy()
    df["_b"] = pd.cut(df.T_amb, bins, labels=False)
    g = df.groupby("_b")[["T_flank_proxy", "T_oil_max", "lambda_mean"]].mean()
    xc = 0.5 * (bins[:-1] + bins[1:])
    ax.plot(xc, g["T_flank_proxy"], "s-", color="#a93226", lw=1.8, ms=6,
            label="Flank proxy T")
    ax.plot(xc, g["T_oil_max"], "o-", color="#b9770e", lw=1.8, ms=6,
            label="Oil bath T")
    ax2 = ax.twinx()
    ax2.plot(xc, g["lambda_mean"], "^-", color="#146b4a", lw=1.8, ms=6,
             ls="--", label="Duty-averaged " + LAM)
    ax2.set_ylabel("Duty-averaged " + LAM, color="#146b4a",
                   fontsize=6.4, labelpad=5)
    ax2.tick_params(axis="y", colors="#146b4a", labelsize=6.8)
    ax2.grid(False)
    ax.set_xlabel("Ambient temperature (" + DEG + "C)", fontsize=7.8)
    ax.set_ylabel("Temperature (" + DEG + "C)", fontsize=7.8)
    ax.tick_params(labelsize=7.0)
    ax.set_ylim(g["T_oil_max"].min() - 1.5, g["T_flank_proxy"].max() + 14)
    h1, l1 = ax.get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, fontsize=6.0, loc="upper center",
              ncol=3, columnspacing=0.7, handlelength=1.1,
              bbox_to_anchor=(0.5, -0.300), framealpha=0.95,
              edgecolor="#c8ced4")
    ax.set_title("(e) Ambient as the second lever", fontsize=9.2, color=INK,
                 pad=6)

    # ---------------- (f) conclusions ---------------------------------------
    ax = fig.add_subplot(gs[1, 2])
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    ax.set_title("(f) Conclusions", fontsize=9.2, color=INK, pad=6)
    concl = [("Film ratio governs the regime",
              "not the gear mean temperature", "#146b4a", "1"),
             ("Duty severity sets the margin",
              "urban keeps it, high speed burns it", "#a93226", "2"),
             ("Cooling and fill are the levers",
              "the gear train is untouched", "#b9770e", "3")]
    y = 0.88
    for name, detail, col, gl in concl:
        ax.add_patch(_Fb((0.0, y - 0.072), 0.062, 0.165,
                         boxstyle="round,pad=0,rounding_size=0.010",
                         fc=col, ec="none"))
        ax.text(0.031, y + 0.012, gl, fontsize=7.2, color="white",
                ha="center", va="center", fontweight="bold")
        ax.text(0.090, y + 0.050, name, fontsize=7.2, color=INK,
                va="center", fontweight="bold")
        ax.text(0.090, y - 0.036, detail, fontsize=6.5, color=SUB,
                va="center")
        y -= 0.335

    fig.suptitle("Concept map of the design question.", fontsize=9.8,
                 y=0.975, color=INK)
    polish(fig)
    fig.savefig(os.path.join(FIGS, "F11_concept.png"))
    plt.close(fig)




def main():
    solver = FVEaxleSolver(nx=40, ny=28, nz=28)
    sims = load_sims()
    ss = load_json(os.path.join(PROC, "cycle_sim_summary.json"), {})
    print(" 1/11 driving cycles");          figure1_cycles()
    print(" 2/11 study framework");         figure2_framework()
    print(" 3/11 model and mesh");          figure3_model(solver)
    print(" 5/11 fields and cycle");        figure5_fields_cycle(solver, sims, ss)
    print(" 6/11 lubrication");             figure6_lubrication(solver, sims, ss)
    print(" 7/11 power budget");            figure7_power(solver)
    print(" 8/12 DOE + waveform");           figure8_doe()
    print(" 9/11 transfer");                figure9_transfer()
    print("10/11 mechanism");               figure10_mechanism(solver)
    print("11/11 concept map");             figure11_concept()
    print("\n11 figures written (60 original panels carried over)")


if __name__ == "__main__":
    main()