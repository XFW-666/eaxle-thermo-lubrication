# Data dictionary

## data/raw/

Second-by-second speed schedules, redistributed exactly as published. Each file
is tab- or comma-delimited with a one- or two-line header; column 1 is time in
seconds, column 2 is vehicle speed in the unit stated in that header.

| file | schedule | speed unit | duration | distance |
|---|---|---|---|---|
| `epa_udds.txt` | Urban Dynamometer Driving Schedule | mph | 1370 s | 11.99 km |
| `epa_ftp.txt` | Federal Test Procedure (FTP-75) | mph | 1875 s | 17.77 km |
| `epa_us06.txt` | US06 Supplemental FTP | mph | 601 s | 12.89 km |
| `epa_sc03.txt` | SC03 Supplemental FTP (air conditioning) | mph | 601 s | 5.76 km |
| `epa_hwy.txt` | Highway Fuel Economy Test | mph | 766 s | 16.51 km |
| `epa_ece.txt` | UN/ECE Elementary Urban Cycle | km/h | 196 s | 0.99 km |
| `epa_eudc.txt` | UN/ECE Extra-Urban Driving Cycle | km/h | 401 s | 6.95 km |
| `epa_jpn10.txt` | Japanese 10-mode cycle | km/h | 136 s | 0.66 km |

Distances are integrated from the traces and agree with the published values to
within 1.4 % in the worst case.

## data/processed/

| file | contents |
|---|---|
| `cycle_<name>.npz` | parsed and resampled trace: `t` (s), `v` (in the source unit), plus the integrated statistics |
| `cycle_<name>_sim.npz` | solver output for that cycle: time histories of flank, oil, housing and shaft temperature, mesh power, film ratio, viscosity |
| `cycle_summary.json` | per-cycle statistics: duration, distance, peak and mean speed, peak acceleration, positive-kinetic-energy density, stop count |
| `cycle_sim_summary.json` | per-cycle peak temperatures, peak mesh power, integrated mesh energy, minimum film ratio |
| `doe_design.csv` | 160-point Latin-hypercube design over the six design variables |
| `doe_results.csv` | solver response at every design point |
| `doe_waveform_features.csv` | the nine duty-waveform descriptors evaluated at each design point |
| `cycle_waveform_features.csv` | the same descriptors for the eight certified cycles (used for the transfer test) |
| `lptn_comparison.json` | lumped-network versus three-dimensional results by cycle, including the film-ratio ratio |
| `surrogate_wf.json` | held-out accuracy for every family, baseline and waveform-augmented, plus the transfer results |
| `envelope_map.json` | minimum film ratio over the speed-ambient grid and the full-film boundary |
| `sobol_jansen.json` | first-order and total-order indices per response quantity |
| `feature_importance.json` | permutation importance of the augmented model |

## Units

Temperatures are degrees Celsius throughout; the exception is the interface
between the solver and the tribological sub-model, which uses kelvin internally.
Film ratio is dimensionless. Mesh power is in watts, mesh energy in kilojoules.
Design variables: mean duty speed in m·s⁻¹, final-drive ratio dimensionless,
external convective coefficient in W·m⁻²·K⁻¹, oil fill as a fraction of cavity
height, ambient and coolant inlet temperature in °C.
