# Three-dimensional thermo-lubrication model of a single-stage EV e-axle

Code and data accompanying the manuscript

> **Physics-Informed Machine-Learning Surrogates for Three-Dimensional
> Thermo-Lubrication Modelling of an Electric Drive Unit under Certified Duty
> Cycles**

The release contains the finite-volume solver, the duty-cycle pipeline, the
surrogate training code, the benchmark models and the scripts that generate every
figure and table in the paper. The pipeline is deterministic — all random seeds
are fixed — so a re-run reproduces the published numbers.

## Contents

```
src/
  fv_eaxle.py              three-dimensional finite-volume solver (five regions)
  parse_cycles.py          EPA / UN-ECE speed-schedule ingestion and validation
  run_simulation.py        cycle-resolved simulation and the LHS design of experiments
  lptn.py                  four-node lumped-parameter network benchmark
  waveform_features.py     duty-waveform descriptors and the trace unit converter
  train_surrogate.py       surrogate families, including the physics-informed residual net
  train_surrogate_wf.py    baseline vs waveform-augmented training and transfer test
  envelope_map.py          fifty-point scuffing-limited envelope sweep
  sobol_jansen.py          Jansen variance-based sensitivity indices
  make_final_figures.py    Figures 1-7
  make_novelty_figures.py  Figures 8-10

data/raw/          second-by-second speed schedules as published (EPA / UN-ECE)
data/processed/    parsed traces, design of experiments, solver output, model results
figures/           the ten published figures at 300 dpi
docs/              data dictionary
```

## Requirements

Python 3.10 or newer with

```
numpy  pandas  scikit-learn  matplotlib  scipy
```

`python -m pip install -r requirements.txt` installs the exact versions used for
the published results.

## Reproducing the results

Run from the repository root, in this order:

| step | command | what it produces | approximate cost |
|---|---|---|---|
| 1 | `python src/parse_cycles.py` | parsed traces and cycle statistics | seconds |
| 2 | `python src/run_simulation.py` | cycle-resolved fields and the 160-point design | 1-2 h |
| 3 | `python src/lptn.py` | lumped-network benchmark | under a minute |
| 4 | `python src/envelope_map.py` | fifty-point envelope sweep | ~7 min |
| 5 | `python src/sobol_jansen.py` | sensitivity indices | minutes |
| 6 | `python src/train_surrogate_wf.py` | baseline and waveform-augmented surrogates | under a minute |
| 7 | `python src/make_final_figures.py` | Figures 1-7 | under a minute |
| 8 | `python src/make_novelty_figures.py` | Figures 8-10 | under a minute |

Step 2 dominates the runtime because it resolves 160 design points in three
dimensions; the cycle simulations alone take about 90 s.

## Input data

All driving cycles are public-domain regulatory schedules:

- U.S. Environmental Protection Agency, *Dynamometer Drive Schedules*,
  <https://www.epa.gov/vehicle-and-fuel-emissions-testing/dynamometer-drive-schedules>
- 40 CFR Part 86, Appendix I
- UN/ECE Regulation 83 (ECE and EUDC schedules)

The files are redistributed unmodified. Note that the EPA schedules are tabulated
in miles per hour and the UN-ECE schedules in kilometres per hour; the column
header of each file states which, and `waveform_features.trace_speed_mps` applies
the corresponding conversion.

## Licence

- Code (`src/`): MIT, see `LICENSE-CODE`.
- Data (`data/`, `figures/`): CC BY 4.0, see `LICENSE-DATA`. The raw EPA
  schedules are public domain in their country of origin and are included here
  under that status.

## Citation

If you use this release, please cite the manuscript and the archive:

```
Gao L., Sun J., Yan W., Xue F., Jin R. Physics-Informed Machine-Learning
Surrogates for Three-Dimensional Thermo-Lubrication Modelling of an Electric
Drive Unit under Certified Duty Cycles. Frontiers in Mechanical Engineering
(Research Topic: Intelligent Tribology). doi: [manuscript DOI]

Gao L., Sun J., Yan W., Xue F., Jin R. Code and data for: Physics-Informed
Machine-Learning Surrogates for Three-Dimensional Thermo-Lubrication Modelling
of an Electric Drive Unit. Zenodo. doi: [archive DOI]
```

A `CITATION.cff` is included, so GitHub renders a "Cite this repository" button.

## Data availability statement

The text below can be adapted for the manuscript; the identifiers in square
brackets are filled in once the archive has been minted.

> All driving-cycle data are public domain and were retrieved from the U.S.
> Environmental Protection Agency drive-schedule archive
> (<https://www.epa.gov/vehicle-and-fuel-emissions-testing/dynamometer-drive-schedules>)
> and 40 CFR Part 86, Appendix I. All derived data, the finite-volume solver,
> the design of experiments and the trained surrogate models are openly
> available at <https://doi.org/[archive DOI]> (archived release v1.0.0; the
> source is also at <https://github.com/[username]/eaxle-thermo-lubrication>,
> MIT for the code and CC BY 4.0 for the data). The pipeline is deterministic,
> with all random seeds fixed, and reproduces every table and figure when
> re-run.

## Contact

Corresponding author: Ruixin Jin, School of New Energy Vehicle Engineering,
Luoyang Vocational College of Science and Technology, Luoyang 471822, China.
<jinruixin@mail.xingaojiao.com>
